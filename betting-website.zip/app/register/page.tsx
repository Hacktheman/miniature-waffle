"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Trophy, Gift, Shield, Users, Loader2 } from "lucide-react"
import Link from "next/link"
import { getCountryFromIP } from "@/lib/geo"
import { authService } from "@/lib/auth"
import { useRouter } from "next/navigation"

export default function RegisterPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [geoData, setGeoData] = useState({ country: "Kenya", minAge: 18 })
  const [formData, setFormData] = useState({
    phone: "",
    password: "",
    confirmPassword: "",
    agreeTerms: false,
  })

  useEffect(() => {
    // Get user's country and minimum age requirement
    getCountryFromIP().then((data) => {
      setGeoData(data)
      setLoading(false)
    })
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      alert("Passwords don't match")
      return
    }

    if (formData.password.length < 6) {
      alert("Password must be at least 6 characters long")
      return
    }

    // Register user with default values
    const user = authService.register({
      firstName: "User",
      lastName: `${Date.now()}`, // Generate unique last name
      phone: formData.phone,
      password: formData.password,
      country: geoData.country,
      age: geoData.minAge, // Use minimum age as default
    })

    alert("✅ Registration successful! Welcome to SportBet Pro!")
    router.push("/")
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-blue-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-white mx-auto mb-4" />
          <p className="text-white">Detecting your location...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-blue-900">
      {/* Header */}
      <header className="bg-blue-800 border-b border-blue-600">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <Trophy className="h-8 w-8 text-yellow-400" />
              <span className="text-2xl font-bold text-white">SportBet Pro</span>
            </Link>
            <Link href="/">
              <Button
                variant="outline"
                className="text-white border-white hover:bg-white hover:text-blue-800 bg-transparent"
              >
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Registration Form */}
            <Card className="bg-white/10 border-blue-600 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Create Your Account</CardTitle>
                <CardDescription className="text-blue-300">
                  Join thousands of winners from {geoData.country} and start betting today!
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="phone" className="text-white text-base">
                      Phone Number
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder={geoData.country === "Kenya" ? "0712345678" : "+1234567890"}
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="bg-white/10 border-blue-600 text-white placeholder:text-blue-300 h-12"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="password" className="text-white text-base">
                      Password
                    </Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter a secure password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="bg-white/10 border-blue-600 text-white placeholder:text-blue-300 h-12"
                      required
                      minLength={6}
                    />
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword" className="text-white text-base">
                      Confirm Password
                    </Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Confirm your password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      className="bg-white/10 border-blue-600 text-white placeholder:text-blue-300 h-12"
                      required
                    />
                  </div>

                  <div className="flex items-start space-x-3 p-4 bg-blue-600/20 rounded-lg border border-blue-500">
                    <Checkbox
                      id="terms"
                      checked={formData.agreeTerms}
                      onCheckedChange={(checked) => setFormData({ ...formData, agreeTerms: checked as boolean })}
                      className="mt-1"
                    />
                    <Label htmlFor="terms" className="text-white text-sm leading-relaxed">
                      I confirm that I am at least {geoData.minAge} years old and agree to the{" "}
                      <Link href="/terms" className="text-yellow-400 hover:underline font-semibold">
                        Terms & Conditions
                      </Link>{" "}
                      and{" "}
                      <Link href="/privacy" className="text-yellow-400 hover:underline font-semibold">
                        Privacy Policy
                      </Link>
                    </Label>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold py-4 text-lg"
                    disabled={!formData.agreeTerms}
                  >
                    Create Account & Claim 300% Bonus
                  </Button>

                  <p className="text-center text-white text-sm">
                    Already have an account?{" "}
                    <Link href="/" className="text-yellow-400 hover:underline font-semibold">
                      Login here
                    </Link>
                  </p>
                </form>
              </CardContent>
            </Card>

            {/* Benefits */}
            <div className="space-y-6">
              <Card className="bg-gradient-to-r from-yellow-400 to-orange-500 border-0 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <Gift className="h-12 w-12 text-black" />
                    <div>
                      <h3 className="text-xl font-bold text-black">300% Welcome Bonus</h3>
                      <p className="text-black/80">Get up to KSH 30,000 bonus on your first deposit</p>
                      <p className="text-black font-semibold">✓ Withdrawable bonus</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="bg-blue-600/20 p-6 rounded-lg border border-blue-500 backdrop-blur-sm">
                <h4 className="font-semibold text-white mb-3 text-lg">Available in {geoData.country}</h4>
                <ul className="text-blue-300 space-y-2">
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div>
                    M-Pesa deposits and withdrawals
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div>
                    USDT cryptocurrency support
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div>
                    Bitcoin & PayPal withdrawals
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div>
                    24/7 local customer support
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div>
                    Secure & licensed platform
                  </li>
                </ul>
              </div>

              <div className="grid grid-cols-1 gap-4">
                <Card className="bg-white/10 border-blue-600 backdrop-blur-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Shield className="h-8 w-8 text-blue-400" />
                      <div>
                        <h4 className="font-semibold text-white">Secure & Licensed</h4>
                        <p className="text-blue-300 text-sm">Your money is safe with us</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 border-blue-600 backdrop-blur-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Users className="h-8 w-8 text-blue-400" />
                      <div>
                        <h4 className="font-semibold text-white">24/7 Support</h4>
                        <p className="text-blue-300 text-sm">Get help whenever you need it</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 border-blue-600 backdrop-blur-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Trophy className="h-8 w-8 text-yellow-400" />
                      <div>
                        <h4 className="font-semibold text-white">Best Odds</h4>
                        <p className="text-blue-300 text-sm">Competitive odds on all sports</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 p-6 rounded-lg border border-blue-500 backdrop-blur-sm">
                <h4 className="font-semibold text-white mb-3">Why Choose SportBet Pro?</h4>
                <div className="grid grid-cols-1 gap-2 text-blue-300 text-sm">
                  <div className="flex items-center">
                    <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-2"></div>
                    Live betting on all major sports
                  </div>
                  <div className="flex items-center">
                    <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-2"></div>
                    Instant deposits and withdrawals
                  </div>
                  <div className="flex items-center">
                    <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-2"></div>
                    Mobile-friendly platform
                  </div>
                  <div className="flex items-center">
                    <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-2"></div>
                    Regular promotions and bonuses
                  </div>
                  <div className="flex items-center">
                    <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-2"></div>
                    Responsible gambling tools
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
