"use client"

export interface ChatMessage {
  id: number
  userId: number
  userName: string
  userPhone: string
  message: string
  timestamp: string
  status: "Pending" | "Responded" | "Resolved"
  adminResponse?: string
  adminResponseTime?: string
}

// Mock chat storage
let chatMessages: ChatMessage[] = []
let messageIdCounter = 1

export const chatService = {
  sendMessage: (userId: number, userName: string, userPhone: string, message: string) => {
    const newMessage: ChatMessage = {
      id: messageIdCounter++,
      userId,
      userName,
      userPhone,
      message,
      timestamp: new Date().toISOString(),
      status: "Pending",
    }

    chatMessages.push(newMessage)

    // Store in localStorage for persistence
    if (typeof window !== "undefined") {
      localStorage.setItem("chatMessages", JSON.stringify(chatMessages))
    }

    // Notify admin (in real app, this would be a WebSocket or server notification)
    console.log("🔔 New chat message:", newMessage)

    return newMessage
  },

  getPendingMessages: (): ChatMessage[] => {
    // Load from localStorage on first call
    if (typeof window !== "undefined" && chatMessages.length === 0) {
      const stored = localStorage.getItem("chatMessages")
      if (stored) {
        chatMessages = JSON.parse(stored)
        messageIdCounter = Math.max(...chatMessages.map((m) => m.id), 0) + 1
      }
    }
    return chatMessages.filter((m) => m.status === "Pending")
  },

  getAllMessages: (): ChatMessage[] => {
    // Load from localStorage
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("chatMessages")
      if (stored) {
        chatMessages = JSON.parse(stored)
      }
    }
    return chatMessages
  },

  getUserMessages: (userId: number): ChatMessage[] => {
    return chatMessages.filter((m) => m.userId === userId)
  },

  respondToMessage: (messageId: number, adminResponse: string) => {
    const messageIndex = chatMessages.findIndex((m) => m.id === messageId)
    if (messageIndex !== -1) {
      chatMessages[messageIndex].status = "Responded"
      chatMessages[messageIndex].adminResponse = adminResponse
      chatMessages[messageIndex].adminResponseTime = new Date().toISOString()

      // Update localStorage
      if (typeof window !== "undefined") {
        localStorage.setItem("chatMessages", JSON.stringify(chatMessages))
      }

      return chatMessages[messageIndex]
    }
    return null
  },

  resolveMessage: (messageId: number) => {
    const messageIndex = chatMessages.findIndex((m) => m.id === messageId)
    if (messageIndex !== -1) {
      chatMessages[messageIndex].status = "Resolved"

      // Update localStorage
      if (typeof window !== "undefined") {
        localStorage.setItem("chatMessages", JSON.stringify(chatMessages))
      }

      return chatMessages[messageIndex]
    }
    return null
  },
}
