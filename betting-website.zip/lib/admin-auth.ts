"use client"

export interface AdminUser {
  username: string
  password: string
  role: string
}

// Admin credentials
const adminCredentials: AdminUser[] = [
  {
    username: "admin",
    password: "admin123",
    role: "Super Admin",
  },
  {
    username: "manager",
    password: "manager123",
    role: "Manager",
  },
  {
    username: "support",
    password: "support123",
    role: "Support",
  },
]

export const adminAuthService = {
  login: (username: string, password: string): AdminUser | null => {
    const admin = adminCredentials.find((cred) => cred.username === username && cred.password === password)

    if (admin) {
      if (typeof window !== "undefined") {
        localStorage.setItem("adminUser", JSON.stringify(admin))
      }
      return admin
    }
    return null
  },

  getCurrentAdmin: (): AdminUser | null => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("adminUser")
      return stored ? JSON.parse(stored) : null
    }
    return null
  },

  logout: () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("adminUser")
    }
  },

  isAuthenticated: (): boolean => {
    return adminAuthService.getCurrentAdmin() !== null
  },
}
