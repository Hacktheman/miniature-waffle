"use client"

export interface User {
  id: number
  firstName: string
  lastName: string
  phone: string
  balance: number
  country: string
  age: number
  status: "Active" | "Suspended"
  joined: string
}

export interface Bet {
  id: number
  userId: number
  match: string
  selection: string
  odds: number
  stake: number
  potentialWin: number
  status: "Pending" | "Won" | "Lost"
  placedAt: string
}

// Mock user database - Load from localStorage if available
let users: User[] = []

// Initialize users from localStorage or use default
if (typeof window !== "undefined") {
  const storedUsers = localStorage.getItem("users")
  if (storedUsers) {
    users = JSON.parse(storedUsers)
  } else {
    users = [
      {
        id: 1,
        firstName: "User",
        lastName: "1001",
        phone: "0712345678",
        balance: 1250,
        country: "Kenya",
        age: 25,
        status: "Active",
        joined: "2024-12-01",
      },
    ]
    localStorage.setItem("users", JSON.stringify(users))
  }
}

const bets: Bet[] = []

// Helper function to save users to localStorage
const saveUsers = () => {
  if (typeof window !== "undefined") {
    localStorage.setItem("users", JSON.stringify(users))
  }
}

// Helper function to broadcast user updates
const broadcastUserUpdate = () => {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("userUpdate", { detail: users }))
  }
}

export const authService = {
  register: (userData: {
    firstName: string
    lastName: string
    phone: string
    password: string
    country: string
    age: number
  }) => {
    const newUser: User = {
      id: users.length + 1,
      firstName: userData.firstName,
      lastName: userData.lastName,
      phone: userData.phone,
      balance: 0,
      country: userData.country,
      age: userData.age,
      status: "Active",
      joined: new Date().toISOString().split("T")[0],
    }
    users.push(newUser)
    saveUsers()

    // Broadcast user registration immediately
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("userRegistered", { detail: newUser }))
      window.dispatchEvent(new CustomEvent("userUpdate", { detail: users }))
    }

    localStorage.setItem("currentUser", JSON.stringify(newUser))
    return newUser
  },

  login: (phone: string, password: string) => {
    const user = users.find((u) => u.phone === phone)
    if (user) {
      localStorage.setItem("currentUser", JSON.stringify(user))
      return user
    }
    return null
  },

  getCurrentUser: (): User | null => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("currentUser")
      if (stored) {
        const user = JSON.parse(stored)
        // Get the latest user data from the users array
        const latestUser = users.find((u) => u.id === user.id)
        if (latestUser) {
          localStorage.setItem("currentUser", JSON.stringify(latestUser))
          return latestUser
        }
      }
    }
    return null
  },

  logout: () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("currentUser")
    }
  },

  updateUserBalance: (userId: number, newBalance: number) => {
    users = users.map((user) => (user.id === userId ? { ...user, balance: newBalance } : user))
    saveUsers()
    broadcastUserUpdate()

    // Update current user in localStorage if it's the same user
    const currentUser = authService.getCurrentUser()
    if (currentUser && currentUser.id === userId) {
      const updatedUser = { ...currentUser, balance: newBalance }
      localStorage.setItem("currentUser", JSON.stringify(updatedUser))

      // Broadcast balance update for real-time UI updates
      window.dispatchEvent(new CustomEvent("balanceUpdate", { detail: updatedUser }))
    }
  },

  placeBet: (bet: Omit<Bet, "id" | "placedAt">) => {
    const newBet: Bet = {
      ...bet,
      id: bets.length + 1,
      placedAt: new Date().toISOString(),
    }
    bets.push(newBet)
    return newBet
  },

  getUserBets: (userId: number) => {
    return bets.filter((bet) => bet.userId === userId)
  },

  getAllUsers: () => {
    // Load fresh data from localStorage
    if (typeof window !== "undefined") {
      const storedUsers = localStorage.getItem("users")
      if (storedUsers) {
        users = JSON.parse(storedUsers)
      }
    }
    return users
  },

  getAllBets: () => bets,

  // Add method to get user by ID
  getUserById: (userId: number): User | null => {
    return users.find((user) => user.id === userId) || null
  },
}
