"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, X } from "lucide-react"

interface MinBetPopupProps {
  onClose: () => void
}

export function MinBetPopup({ onClose }: MinBetPopupProps) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="bg-gradient-to-br from-orange-500/20 to-red-500/20 border-orange-500 shadow-2xl backdrop-blur-sm max-w-sm w-full animate-in zoom-in-95 duration-300">
        <CardContent className="p-6">
          <div className="text-center">
            {/* Close Button */}
            <div className="flex justify-end mb-2">
              <Button size="sm" variant="ghost" onClick={onClose} className="text-white hover:bg-white/20 h-8 w-8 p-0">
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Icon */}
            <div className="relative mx-auto w-16 h-16 mb-4">
              <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-red-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-2 bg-orange-900 rounded-full flex items-center justify-center">
                <AlertTriangle className="h-8 w-8 text-orange-300" />
              </div>
            </div>

            {/* Title */}
            <h3 className="text-xl font-bold text-white mb-2">Minimum Stake Required</h3>

            {/* Message */}
            <div className="bg-white/10 rounded-lg p-4 mb-4 border border-orange-500/30">
              <p className="text-orange-200 text-sm mb-2">The minimum stake amount is:</p>
              <div className="text-orange-300 text-2xl font-bold mb-2">KSH 10</div>
              <p className="text-orange-200 text-xs">Please enter at least KSH 10 to place your bet</p>
            </div>

            {/* Action Button */}
            <Button
              onClick={onClose}
              className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-bold py-3 shadow-xl transition-all duration-300 transform hover:scale-105"
            >
              Got It!
            </Button>

            {/* Info */}
            <p className="text-orange-300 text-xs mt-3">💡 Higher stakes = Higher potential winnings!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
