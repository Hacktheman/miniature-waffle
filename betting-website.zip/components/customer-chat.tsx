"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { MessageCircle, Send, X, Clock, CheckCircle, Headphones } from "lucide-react"
import { authService } from "@/lib/auth"
import { chatService } from "@/lib/chat-service"

interface CustomerChatProps {
  isOpen: boolean
  onClose: () => void
}

export function CustomerChat({ isOpen, onClose }: CustomerChatProps) {
  const [message, setMessage] = useState("")
  const [userMessages, setUserMessages] = useState<any[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const currentUser = authService.getCurrentUser()

  useEffect(() => {
    if (currentUser && isOpen) {
      const messages = chatService.getUserMessages(currentUser.id)
      setUserMessages(messages)
    }
  }, [currentUser, isOpen])

  const handleSendMessage = async () => {
    if (!currentUser || !message.trim()) return

    setIsSubmitting(true)

    try {
      const newMessage = chatService.sendMessage(
        currentUser.id,
        `${currentUser.firstName} ${currentUser.lastName}`,
        currentUser.phone,
        message.trim(),
      )

      // Update local messages
      setUserMessages([...userMessages, newMessage])
      setMessage("")

      // Show success feedback
      alert("✅ Message sent successfully! Our support team will respond shortly.")
    } catch (error) {
      alert("❌ Failed to send message. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end justify-end p-4">
      <Card className="bg-gradient-to-br from-blue-900/95 to-indigo-900/95 border-blue-500 shadow-2xl backdrop-blur-sm w-full max-w-md h-[600px] flex flex-col">
        <CardHeader className="flex-shrink-0">
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center text-xl">
              <Headphones className="h-6 w-6 mr-3 text-blue-400" />
              Customer Support
              <div className="ml-3 flex items-center">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2"></div>
                <span className="text-green-400 text-sm">Online</span>
              </div>
            </CardTitle>
            <Button size="sm" variant="ghost" onClick={onClose} className="text-white hover:bg-white/20 h-8 w-8 p-0">
              <X className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-blue-300 text-sm">
            Get instant help from our support team. We're here 24/7 to assist you!
          </p>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col space-y-4 overflow-hidden">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto space-y-3 bg-white/5 rounded-lg p-4 border border-blue-600">
            {userMessages.length === 0 ? (
              <div className="text-center py-8">
                <MessageCircle className="h-12 w-12 text-blue-400 mx-auto mb-3" />
                <p className="text-blue-300">No messages yet</p>
                <p className="text-blue-400 text-sm">Start a conversation with our support team</p>
              </div>
            ) : (
              userMessages.map((msg) => (
                <div key={msg.id} className="space-y-3">
                  {/* User Message */}
                  <div className="flex justify-end">
                    <div className="bg-blue-600 text-white p-3 rounded-lg max-w-[80%]">
                      <p className="text-sm">{msg.message}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-blue-200">{new Date(msg.timestamp).toLocaleTimeString()}</span>
                        <Badge
                          variant="outline"
                          className={`text-xs ${
                            msg.status === "Pending"
                              ? "border-yellow-400 text-yellow-400"
                              : msg.status === "Responded"
                                ? "border-green-400 text-green-400"
                                : "border-blue-400 text-blue-400"
                          }`}
                        >
                          {msg.status === "Pending" ? (
                            <Clock className="h-3 w-3 mr-1" />
                          ) : (
                            <CheckCircle className="h-3 w-3 mr-1" />
                          )}
                          {msg.status}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {/* Admin Response */}
                  {msg.adminResponse && (
                    <div className="flex justify-start">
                      <div className="bg-green-600 text-white p-3 rounded-lg max-w-[80%]">
                        <div className="flex items-center mb-2">
                          <Headphones className="h-4 w-4 mr-2" />
                          <span className="font-bold text-sm">Support Team</span>
                        </div>
                        <p className="text-sm">{msg.adminResponse}</p>
                        <span className="text-xs text-green-200 mt-2 block">
                          {new Date(msg.adminResponseTime!).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          {/* Message Input */}
          <div className="flex-shrink-0 space-y-3">
            <div>
              <Label htmlFor="message" className="text-white text-sm">
                Your Message
              </Label>
              <Textarea
                id="message"
                placeholder="Type your message, question, or complaint here..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="bg-white/10 border-blue-600 text-white resize-none h-20"
                maxLength={500}
              />
              <p className="text-blue-400 text-xs mt-1">{message.length}/500 characters</p>
            </div>

            <Button
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-3 shadow-xl transition-all duration-300 transform hover:scale-105"
              onClick={handleSendMessage}
              disabled={isSubmitting || !message.trim() || !currentUser}
            >
              {isSubmitting ? (
                <>
                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Send Message
                </>
              )}
            </Button>

            <div className="bg-blue-600/20 p-3 rounded-lg border border-blue-500">
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-green-400 text-sm font-bold">24/7 Support Available</span>
              </div>
              <p className="text-blue-300 text-xs">
                Our support team typically responds within 5-10 minutes. For urgent issues, please include your phone
                number.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
