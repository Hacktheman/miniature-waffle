"use client"

export const getCountryFromIP = async (): Promise<{ country: string; minAge: number }> => {
  try {
    // In a real app, you'd use a proper IP geolocation service
    // For demo, we'll simulate different countries
    const mockCountries = [
      { country: "Kenya", minAge: 18 },
      { country: "Nigeria", minAge: 18 },
      { country: "South Africa", minAge: 18 },
      { country: "Ghana", minAge: 18 },
      { country: "Uganda", minAge: 18 },
      { country: "Tanzania", minAge: 18 },
      { country: "United States", minAge: 21 },
      { country: "United Kingdom", minAge: 18 },
      { country: "Canada", minAge: 19 },
      { country: "Australia", minAge: 18 },
    ]

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Return random country for demo
    const randomCountry = mockCountries[Math.floor(Math.random() * mockCountries.length)]
    return randomCountry
  } catch (error) {
    // Default fallback
    return { country: "Kenya", minAge: 18 }
  }
}
