"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, CheckCircle, Zap, X } from "lucide-react"

interface WithdrawalCountdownProps {
  amount: number
  method: string
  onComplete: () => void
  onCancel: () => void
}

export function WithdrawalCountdown({ amount, method, onComplete, onCancel }: WithdrawalCountdownProps) {
  const [timeLeft, setTimeLeft] = useState(30) // 30 seconds
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        const newTime = prev - 1
        setProgress(((30 - newTime) / 30) * 100)

        if (newTime <= 0) {
          clearInterval(interval)
          onComplete()
          return 0
        }
        return newTime
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [onComplete])

  const getStatusColor = () => {
    if (timeLeft > 20) return "text-green-400"
    if (timeLeft > 10) return "text-yellow-400"
    return "text-red-400"
  }

  const getProgressColor = () => {
    if (timeLeft > 20) return "from-green-500 to-green-600"
    if (timeLeft > 10) return "from-yellow-500 to-yellow-600"
    return "from-red-500 to-red-600"
  }

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="bg-gradient-to-br from-blue-900/95 to-indigo-900/95 border-blue-500 shadow-2xl backdrop-blur-sm max-w-sm w-full">
        <CardContent className="p-6">
          <div className="text-center">
            {/* Close Button */}
            <div className="flex justify-end mb-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={onCancel}
                className="text-white hover:bg-white/20 h-8 w-8 p-0"
                disabled={timeLeft < 5}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Header */}
            <div className="mb-4">
              <div className="relative mx-auto w-16 h-16 mb-3">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full animate-pulse"></div>
                <div className="absolute inset-2 bg-blue-900 rounded-full flex items-center justify-center">
                  <Clock className="h-6 w-6 text-white" />
                </div>
              </div>
              <h2 className="text-xl font-bold text-white mb-1">Processing Withdrawal</h2>
              <p className="text-blue-300 text-sm">Please wait while we process your request</p>
            </div>

            {/* Withdrawal Details */}
            <div className="bg-white/10 rounded-lg p-3 mb-4 border border-blue-500/30">
              <div className="flex items-center justify-between mb-1">
                <span className="text-blue-300 text-sm">Amount:</span>
                <span className="text-white font-bold">KSH {amount.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-blue-300 text-sm">Method:</span>
                <span className="text-white font-bold text-sm">{method}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-blue-300 text-sm">Fee:</span>
                <span className="text-green-400 font-bold text-sm">FREE</span>
              </div>
            </div>

            {/* Countdown Timer */}
            <div className="mb-4">
              <div className="relative w-20 h-20 mx-auto mb-3">
                {/* Background Circle */}
                <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 80 80">
                  <circle
                    cx="40"
                    cy="40"
                    r="32"
                    stroke="currentColor"
                    strokeWidth="6"
                    fill="none"
                    className="text-blue-800"
                  />
                  <circle
                    cx="40"
                    cy="40"
                    r="32"
                    stroke="url(#gradient)"
                    strokeWidth="6"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 32}`}
                    strokeDashoffset={`${2 * Math.PI * 32 * (1 - progress / 100)}`}
                    className="transition-all duration-1000 ease-linear"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" className="stop-color-blue-400" />
                      <stop offset="100%" className="stop-color-purple-500" />
                    </linearGradient>
                  </defs>
                </svg>

                {/* Timer Text */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className={`text-xl font-bold ${getStatusColor()}`}>{timeLeft}s</div>
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-blue-800/50 rounded-full h-2 mb-3">
                <div
                  className={`h-2 rounded-full bg-gradient-to-r ${getProgressColor()} transition-all duration-1000 ease-linear`}
                  style={{ width: `${progress}%` }}
                />
              </div>

              <p className="text-blue-300 text-xs">
                {timeLeft > 20 ? "Verifying..." : timeLeft > 10 ? "Processing..." : "Almost done..."}
              </p>
            </div>

            {/* Status Steps */}
            <div className="mb-4">
              <div className="flex items-center justify-center space-x-4 text-xs">
                <div className="flex items-center space-x-1">
                  <CheckCircle className="h-3 w-3 text-green-400" />
                  <span className="text-green-400">Received</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 border border-yellow-400 rounded-full animate-spin"></div>
                  <span className="text-yellow-400">Processing</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 border border-blue-600 rounded-full"></div>
                  <span className="text-blue-400">Complete</span>
                </div>
              </div>
            </div>

            {/* Action Button */}
            <Button
              className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-2 text-sm"
              disabled
            >
              <Zap className="h-3 w-3 mr-1" />
              Processing...
            </Button>

            {/* Security Notice */}
            <div className="mt-3 p-2 bg-green-500/20 rounded border border-green-500/30">
              <div className="flex items-center justify-center space-x-1">
                <CheckCircle className="h-3 w-3 text-green-400" />
                <span className="text-green-400 text-xs font-bold">Secure & FREE</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
