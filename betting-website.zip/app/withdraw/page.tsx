"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, ArrowLeft, Smartphone, CreditCard, AlertCircle, Bitcoin, DollarSign, CheckCircle } from "lucide-react"
import Link from "next/link"
import { authService } from "@/lib/auth"
import { WithdrawalCountdown } from "@/components/withdrawal-countdown"
import { WithdrawalSuccess } from "@/components/withdrawal-success"

export default function WithdrawPage() {
  const [amount, setAmount] = useState("")
  const [method, setMethod] = useState("")
  const [currentUser, setCurrentUser] = useState(authService.getCurrentUser())
  const [withdrawalData, setWithdrawalData] = useState({
    mpesaNumber: "",
    usdtAddress: "",
    btcAddress: "",
    paypalEmail: "",
    bankName: "",
    accountNumber: "",
    accountName: "",
  })
  const [showCountdown, setShowCountdown] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  useEffect(() => {
    const user = authService.getCurrentUser()
    setCurrentUser(user)
  }, [])

  const handleWithdrawal = () => {
    if (!currentUser || !amount || !method) {
      alert("Please fill in all required fields")
      return
    }

    const withdrawAmount = Number.parseFloat(amount)
    if (withdrawAmount < 100) {
      alert("Minimum withdrawal is KSH 100")
      return
    }

    if (withdrawAmount > currentUser.balance) {
      alert("Insufficient balance")
      return
    }

    // Show countdown
    setShowCountdown(true)
  }

  const handleCountdownComplete = () => {
    setShowCountdown(false)
    setShowSuccess(true)

    // Update user balance
    if (currentUser) {
      const newBalance = currentUser.balance - Number.parseFloat(amount)
      authService.updateUserBalance(currentUser.id, newBalance)
      setCurrentUser({ ...currentUser, balance: newBalance })
    }
  }

  const handleCountdownCancel = () => {
    setShowCountdown(false)
  }

  const handleSuccessClose = () => {
    setShowSuccess(false)

    // Clear form
    setAmount("")
    setMethod("")
    setWithdrawalData({
      mpesaNumber: "",
      usdtAddress: "",
      btcAddress: "",
      paypalEmail: "",
      bankName: "",
      accountNumber: "",
      accountName: "",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      {/* Withdrawal Countdown */}
      {showCountdown && (
        <WithdrawalCountdown
          amount={Number.parseFloat(amount)}
          method={method}
          onComplete={handleCountdownComplete}
          onCancel={handleCountdownCancel}
        />
      )}

      {/* Withdrawal Success */}
      {showSuccess && (
        <WithdrawalSuccess amount={Number.parseFloat(amount)} method={method} onClose={handleSuccessClose} />
      )}

      {/* Header */}
      <header className="bg-gradient-to-r from-blue-800 to-blue-700 border-b border-blue-600 shadow-xl">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <Trophy className="h-10 w-10 text-yellow-400" />
              <span className="text-3xl font-bold text-white">SportBet Pro</span>
            </Link>
            <div className="flex items-center space-x-4">
              {currentUser && (
                <div className="text-white">
                  <span className="text-sm">Balance: </span>
                  <span className="font-bold text-yellow-400 text-lg">KSH {currentUser.balance.toFixed(2)}</span>
                </div>
              )}
              <Link href="/">
                <Button
                  variant="outline"
                  className="text-white border-white hover:bg-white hover:text-blue-800 bg-transparent transition-all duration-300"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Withdrawal Form */}
            <div className="lg:col-span-2">
              <Card className="bg-white/10 border-blue-600 shadow-2xl">
                <CardHeader>
                  <CardTitle className="text-3xl text-white flex items-center">
                    <CreditCard className="h-8 w-8 mr-3" />
                    Withdraw Funds
                  </CardTitle>
                  <CardDescription className="text-blue-300 text-lg">
                    Cash out your winnings quickly and securely
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="methods" className="w-full">
                    <TabsList className="grid w-full grid-cols-1 bg-blue-700 mb-6">
                      <TabsTrigger value="methods" className="data-[state=active]:bg-blue-600 font-bold text-lg">
                        Withdrawal Methods
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="methods" className="space-y-8">
                      <div className="bg-blue-600/20 p-6 rounded-lg border border-blue-500 shadow-lg">
                        <div className="flex items-start space-x-3">
                          <AlertCircle className="h-6 w-6 text-blue-400 mt-0.5" />
                          <div>
                            <h4 className="font-bold text-white text-lg">Withdrawal Requirements</h4>
                            <ul className="text-blue-300 mt-3 space-y-2">
                              <li className="flex items-center">
                                <span className="bg-green-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3">
                                  ✓
                                </span>
                                100% FREE withdrawals - No fees ever!
                              </li>
                              <li className="flex items-center">
                                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3">
                                  •
                                </span>
                                Minimum withdrawal: KSH 100
                              </li>
                              <li className="flex items-center">
                                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3">
                                  •
                                </span>
                                Account must be verified
                              </li>
                              <li className="flex items-center">
                                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3">
                                  •
                                </span>
                                Processing time: 1-24 hours
                              </li>
                              <li className="flex items-center">
                                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3">
                                  •
                                </span>
                                All bonuses are withdrawable
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="withdrawMethod" className="text-white text-lg font-bold">
                          Withdrawal Method
                        </Label>
                        <Select value={method} onValueChange={setMethod}>
                          <SelectTrigger className="bg-white/10 border-blue-600 text-white h-14 text-lg">
                            <SelectValue placeholder="Select withdrawal method" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="M-Pesa">
                              <div className="flex items-center">
                                <Smartphone className="h-4 w-4 mr-2" />
                                M-Pesa
                              </div>
                            </SelectItem>
                            <SelectItem value="USDT">
                              <div className="flex items-center">
                                <Bitcoin className="h-4 w-4 mr-2" />
                                USDT (TRC20)
                              </div>
                            </SelectItem>
                            <SelectItem value="Bitcoin">
                              <div className="flex items-center">
                                <Bitcoin className="h-4 w-4 mr-2" />
                                Bitcoin
                              </div>
                            </SelectItem>
                            <SelectItem value="PayPal">
                              <div className="flex items-center">
                                <DollarSign className="h-4 w-4 mr-2" />
                                PayPal
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {method === "M-Pesa" && (
                        <div className="space-y-6">
                          <div>
                            <Label htmlFor="mpesaNumber" className="text-white text-lg font-bold">
                              M-Pesa Number
                            </Label>
                            <Input
                              id="mpesaNumber"
                              type="tel"
                              placeholder="0712345678"
                              value={withdrawalData.mpesaNumber}
                              onChange={(e) => setWithdrawalData({ ...withdrawalData, mpesaNumber: e.target.value })}
                              className="bg-white/10 border-blue-600 text-white h-14 text-lg"
                            />
                          </div>
                        </div>
                      )}

                      {method === "USDT" && (
                        <div className="space-y-6">
                          <div>
                            <Label htmlFor="usdtAddress" className="text-white text-lg font-bold">
                              USDT Address (TRC20)
                            </Label>
                            <Input
                              id="usdtAddress"
                              placeholder="Enter your USDT TRC20 address"
                              value={withdrawalData.usdtAddress}
                              onChange={(e) => setWithdrawalData({ ...withdrawalData, usdtAddress: e.target.value })}
                              className="bg-white/10 border-blue-600 text-white h-14 text-lg"
                            />
                            <p className="text-yellow-400 text-sm mt-2">⚠️ Only TRC20 network supported</p>
                          </div>
                        </div>
                      )}

                      {method === "Bitcoin" && (
                        <div className="space-y-6">
                          <div>
                            <Label htmlFor="btcAddress" className="text-white text-lg font-bold">
                              Bitcoin Address
                            </Label>
                            <Input
                              id="btcAddress"
                              placeholder="Enter your Bitcoin address"
                              value={withdrawalData.btcAddress}
                              onChange={(e) => setWithdrawalData({ ...withdrawalData, btcAddress: e.target.value })}
                              className="bg-white/10 border-blue-600 text-white h-14 text-lg"
                            />
                          </div>
                        </div>
                      )}

                      {method === "PayPal" && (
                        <div className="space-y-6">
                          <div>
                            <Label htmlFor="paypalEmail" className="text-white text-lg font-bold">
                              PayPal Email
                            </Label>
                            <Input
                              id="paypalEmail"
                              type="email"
                              placeholder="your@email.com"
                              value={withdrawalData.paypalEmail}
                              onChange={(e) => setWithdrawalData({ ...withdrawalData, paypalEmail: e.target.value })}
                              className="bg-white/10 border-blue-600 text-white h-14 text-lg"
                            />
                          </div>
                        </div>
                      )}

                      <div>
                        <Label htmlFor="withdrawAmount" className="text-white text-lg font-bold">
                          Amount (KSH)
                        </Label>
                        <Input
                          id="withdrawAmount"
                          type="number"
                          placeholder="100"
                          min="100"
                          max={currentUser?.balance || 0}
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          className="bg-white/10 border-blue-600 text-white h-14 text-lg"
                        />
                        <div className="bg-gradient-to-r from-green-500/20 to-green-600/20 p-4 rounded-lg border border-green-500 mt-3">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-green-300 text-sm">Withdrawal Amount:</span>
                            <span className="text-white font-bold text-lg">KSH {amount || "0"}</span>
                          </div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-green-300 text-sm">Processing Fee:</span>
                            <span className="text-green-400 font-bold">FREE</span>
                          </div>
                          <div className="flex items-center justify-between border-t border-green-500/30 pt-2">
                            <span className="text-white font-bold">You Will Receive:</span>
                            <span className="text-green-400 font-bold text-xl">KSH {amount || "0"}</span>
                          </div>
                        </div>
                        <div className="flex justify-between text-sm mt-2">
                          <span className="text-blue-300">Minimum: KSH 100</span>
                          <span className="text-blue-300">Available: KSH {currentUser?.balance.toFixed(2) || 0}</span>
                        </div>
                      </div>

                      <div className="flex space-x-3">
                        <Button
                          variant="outline"
                          onClick={() => setAmount("1000")}
                          className="text-white border-blue-600 hover:bg-blue-600 h-12 text-lg"
                        >
                          KSH 1,000
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => setAmount("5000")}
                          className="text-white border-blue-600 hover:bg-blue-600 h-12 text-lg"
                        >
                          KSH 5,000
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => setAmount(currentUser?.balance.toString() || "0")}
                          className="text-white border-blue-600 hover:bg-blue-600 h-12 text-lg"
                        >
                          All
                        </Button>
                      </div>

                      <Button
                        className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-4 text-lg shadow-xl transition-all duration-300 transform hover:scale-105"
                        onClick={handleWithdrawal}
                        disabled={!method || !amount || Number(amount) < 100 || !currentUser}
                      >
                        Request FREE Withdrawal
                      </Button>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>

            {/* Account Summary */}
            <div className="space-y-8">
              <Card className="bg-gradient-to-r from-green-500/20 to-green-600/20 border-green-500 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-white text-xl flex items-center">
                    <CheckCircle className="h-6 w-6 mr-2 text-green-400" />
                    FREE Withdrawals
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-green-400 text-3xl font-bold mb-2">0%</div>
                    <p className="text-green-300 text-lg">Processing Fee</p>
                    <p className="text-white text-sm mt-2">You get exactly what you withdraw!</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/10 border-blue-600 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-white text-xl">Account Balance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex justify-between items-center">
                    <span className="text-blue-300 text-lg">Total Balance:</span>
                    <span className="text-yellow-400 font-bold text-2xl">
                      KSH {currentUser?.balance.toFixed(2) || 0}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-blue-300 text-lg">Withdrawable:</span>
                    <span className="text-green-400 font-bold text-lg">KSH {currentUser?.balance.toFixed(2) || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-blue-300 text-lg">Bonus Balance:</span>
                    <span className="text-orange-400 font-bold text-lg">KSH 0.00</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/10 border-blue-600 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-white text-xl">Withdrawal Methods</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between text-white">
                    <span className="text-lg">M-Pesa:</span>
                    <Badge variant="secondary" className="bg-green-600 text-lg px-3 py-1">
                      Instant
                    </Badge>
                  </div>
                  <div className="flex justify-between text-white">
                    <span className="text-lg">USDT:</span>
                    <Badge variant="secondary" className="bg-blue-600 text-lg px-3 py-1">
                      1-10 mins
                    </Badge>
                  </div>
                  <div className="flex justify-between text-white">
                    <span className="text-lg">Bitcoin:</span>
                    <Badge variant="secondary" className="bg-orange-600 text-lg px-3 py-1">
                      10-30 mins
                    </Badge>
                  </div>
                  <div className="flex justify-between text-white">
                    <span className="text-lg">PayPal:</span>
                    <Badge variant="secondary" className="bg-purple-600 text-lg px-3 py-1">
                      1-24 hours
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <div className="bg-white/5 p-6 rounded-lg border border-blue-600 shadow-xl">
                <h4 className="font-bold text-white mb-3 text-xl">Need Help?</h4>
                <p className="text-blue-300 text-lg mb-4">Questions about withdrawals? Contact our support team.</p>
                <Button
                  variant="outline"
                  className="w-full text-white border-white hover:bg-white hover:text-blue-800 bg-transparent text-lg py-3 transition-all duration-300"
                >
                  Contact Support
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
