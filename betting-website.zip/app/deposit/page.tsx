"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, CreditCard, Smartphone, Gift, ArrowLeft, Copy, CheckCircle, Bitcoin, Clock } from "lucide-react"
import Link from "next/link"
import { authService } from "@/lib/auth"
import { depositService } from "@/lib/deposit-service"
import { Notification } from "@/components/notification"

export default function DepositPage() {
  const [amount, setAmount] = useState("")
  const [usdtAmount, setUsdtAmount] = useState("")
  const [copied, setCopied] = useState(false)
  const [currentUser, setCurrentUser] = useState(authService.getCurrentUser())
  const [phoneNumber, setPhoneNumber] = useState("")
  const [usdtTxHash, setUsdtTxHash] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [notification, setNotification] = useState<{
    show: boolean
    type: "success" | "info" | "warning" | "error"
    title: string
    message: string
    details?: string[]
  }>({ show: false, type: "success", title: "", message: "" })

  useEffect(() => {
    const user = authService.getCurrentUser()
    setCurrentUser(user)
  }, [])

  const showNotification = (
    type: "success" | "info" | "warning" | "error",
    title: string,
    message: string,
    details?: string[],
  ) => {
    setNotification({ show: true, type, title, message, details })
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const calculateBonus = (depositAmount: number) => {
    return Math.min(depositAmount * 3, 30000) // 300% bonus, max 30,000
  }

  const calculateUSDTBonus = (usdAmount: number) => {
    const kshAmount = usdAmount * 150 // Approximate USD to KSH conversion
    return Math.min(kshAmount * 3, 30000)
  }

  const handleMpesaDeposit = async () => {
    if (!currentUser || !amount || !phoneNumber) {
      showNotification("error", "Missing Information", "Please fill in all required fields")
      return
    }

    if (Number(amount) < 200) {
      showNotification("error", "Invalid Amount", "Minimum deposit is KSH 200")
      return
    }

    setIsSubmitting(true)

    try {
      // Submit deposit request
      const depositRequest = {
        userId: currentUser.id,
        amount: Number(amount),
        method: "M-Pesa",
        phoneNumber: phoneNumber,
        reference: `MP${Date.now()}`,
      }

      depositService.submitDeposit(depositRequest)

      // Show success notification
      showNotification("success", "Deposit Submitted! 🎉", "Your M-Pesa deposit request has been sent successfully", [
        `Amount: KSH ${amount} + Bonus: KSH ${calculateBonus(Number(amount)).toLocaleString()}`,
      ])

      // Clear form
      setAmount("")
      setPhoneNumber("")
    } catch (error) {
      showNotification("error", "Submission Failed", "Error submitting deposit. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleUsdtDeposit = async () => {
    if (!currentUser || !usdtAmount) {
      showNotification("error", "Missing Information", "Please fill in all required fields")
      return
    }

    if (Number(usdtAmount) < 20) {
      showNotification("error", "Invalid Amount", "Minimum deposit is $20 USD")
      return
    }

    setIsSubmitting(true)

    try {
      // Submit deposit request
      const depositRequest = {
        userId: currentUser.id,
        amount: Number(usdtAmount) * 150, // Convert to KSH
        method: "USDT",
        reference: usdtTxHash || `USDT${Date.now()}`,
        usdAmount: Number(usdtAmount),
      }

      depositService.submitDeposit(depositRequest)

      // Show success notification
      showNotification(
        "success",
        "USDT Deposit Submitted! 🚀",
        "Your USDT deposit request has been sent successfully",
        [`Amount: $${usdtAmount} + Bonus: KSH ${calculateUSDTBonus(Number(usdtAmount)).toLocaleString()}`],
      )

      // Clear form
      setUsdtAmount("")
      setUsdtTxHash("")
    } catch (error) {
      showNotification("error", "Submission Failed", "Error submitting deposit. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      {/* Notification */}
      {notification.show && (
        <Notification
          type={notification.type}
          title={notification.title}
          message={notification.message}
          details={notification.details}
          onClose={() => setNotification({ ...notification, show: false })}
          duration={8000}
        />
      )}

      {/* Header */}
      <header className="bg-gradient-to-r from-blue-800 to-blue-700 border-b border-blue-600 shadow-xl">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <Trophy className="h-10 w-10 text-yellow-400" />
              <span className="text-3xl font-bold text-white">SportBet Pro</span>
            </Link>
            <div className="flex items-center space-x-4">
              {currentUser && (
                <div className="text-white">
                  <span className="text-sm">Balance: </span>
                  <span className="font-bold text-yellow-400 text-lg">KSH {currentUser.balance.toFixed(2)}</span>
                </div>
              )}
              <Link href="/">
                <Button
                  variant="outline"
                  className="text-white border-white hover:bg-white hover:text-blue-800 bg-transparent transition-all duration-300"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Deposit Form */}
            <div className="lg:col-span-2">
              <Card className="bg-white/10 border-blue-600 shadow-2xl">
                <CardHeader>
                  <CardTitle className="text-3xl text-white flex items-center">
                    <CreditCard className="h-8 w-8 mr-3" />
                    Make a Deposit
                  </CardTitle>
                  <CardDescription className="text-blue-300 text-lg">
                    Fund your account and start winning today!
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="mpesa" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 bg-blue-700 shadow-lg">
                      <TabsTrigger value="mpesa" className="data-[state=active]:bg-blue-600 font-bold text-lg">
                        <Smartphone className="h-5 w-5 mr-2" />
                        M-Pesa
                      </TabsTrigger>
                      <TabsTrigger value="usdt" className="data-[state=active]:bg-blue-600 font-bold text-lg">
                        <Bitcoin className="h-5 w-5 mr-2" />
                        USDT
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="mpesa" className="space-y-8">
                      <div className="bg-gradient-to-r from-blue-600/20 to-blue-500/20 p-6 rounded-lg border border-blue-500 shadow-lg">
                        <h3 className="font-bold text-white mb-4 text-xl">M-Pesa Deposit Instructions</h3>
                        <div className="space-y-3 text-blue-300">
                          <p className="flex items-center">
                            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              1
                            </span>
                            Go to M-Pesa menu on your phone
                          </p>
                          <p className="flex items-center">
                            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              2
                            </span>
                            Select "Lipa na M-Pesa"
                          </p>
                          <p className="flex items-center">
                            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              3
                            </span>
                            Select "Pay Bill"
                          </p>
                          <p className="flex items-center">
                            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              4
                            </span>
                            Enter Business Number: <strong className="text-yellow-400 ml-2">329329</strong>
                          </p>
                          <p className="flex items-center">
                            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              5
                            </span>
                            Enter Account Number: <strong className="text-yellow-400 ml-2">0100406884100</strong>
                          </p>
                          <p className="flex items-center">
                            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              6
                            </span>
                            Enter the amount and confirm
                          </p>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div>
                          <Label htmlFor="phone" className="text-white text-lg font-bold">
                            Your M-Pesa Number
                          </Label>
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="0712345678"
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                            className="bg-white/10 border-blue-600 text-white h-14 text-lg"
                          />
                        </div>

                        <div>
                          <Label htmlFor="amount" className="text-white text-lg font-bold">
                            Amount (KSH)
                          </Label>
                          <Input
                            id="amount"
                            type="number"
                            placeholder="200"
                            min="200"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            className="bg-white/10 border-blue-600 text-white h-14 text-lg"
                          />
                          <p className="text-blue-300 text-sm mt-2">Minimum deposit: KSH 200</p>
                        </div>

                        <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 p-6 rounded-lg border border-yellow-500 shadow-lg">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white font-bold text-lg">Business Number:</p>
                              <p className="text-yellow-400 text-3xl font-bold">329329</p>
                            </div>
                            <Button
                              size="lg"
                              variant="outline"
                              onClick={() => copyToClipboard("329329")}
                              className="text-yellow-400 border-yellow-400 hover:bg-yellow-400 hover:text-black transition-all duration-300"
                            >
                              {copied ? <CheckCircle className="h-6 w-6" /> : <Copy className="h-6 w-6" />}
                            </Button>
                          </div>
                        </div>

                        <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 p-6 rounded-lg border border-yellow-500 shadow-lg">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white font-bold text-lg">Account Number:</p>
                              <p className="text-yellow-400 text-2xl font-bold">0100406884100</p>
                            </div>
                            <Button
                              size="lg"
                              variant="outline"
                              onClick={() => copyToClipboard("0100406884100")}
                              className="text-yellow-400 border-yellow-400 hover:bg-yellow-400 hover:text-black transition-all duration-300"
                            >
                              {copied ? <CheckCircle className="h-6 w-6" /> : <Copy className="h-6 w-6" />}
                            </Button>
                          </div>
                        </div>

                        <Button
                          className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-4 text-lg shadow-xl transition-all duration-300 transform hover:scale-105"
                          onClick={handleMpesaDeposit}
                          disabled={isSubmitting || !amount || !phoneNumber}
                        >
                          {isSubmitting ? (
                            <>
                              <Clock className="h-5 w-5 mr-2 animate-spin" />
                              Processing...
                            </>
                          ) : (
                            "I Have Sent the Money"
                          )}
                        </Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="usdt" className="space-y-8">
                      <div className="bg-gradient-to-r from-green-600/20 to-green-500/20 p-6 rounded-lg border border-green-500 shadow-lg">
                        <h3 className="font-bold text-white mb-4 text-xl">USDT Deposit Instructions</h3>
                        <div className="space-y-3 text-green-300">
                          <p className="flex items-center">
                            <span className="bg-green-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              1
                            </span>
                            Send USDT (TRC20) to the address below
                          </p>
                          <p className="flex items-center">
                            <span className="bg-green-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              2
                            </span>
                            Minimum deposit: $20 USD
                          </p>
                          <p className="flex items-center">
                            <span className="bg-green-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              3
                            </span>
                            Network: Tron (TRC20)
                          </p>
                          <p className="flex items-center">
                            <span className="bg-green-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              4
                            </span>
                            Confirmation time: 1-3 minutes
                          </p>
                          <p className="text-yellow-400 font-bold flex items-center">
                            <span className="bg-yellow-600 text-black rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3">
                              ⚠
                            </span>
                            Only send USDT TRC20 to this address
                          </p>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div>
                          <Label htmlFor="usdtAmount" className="text-white text-lg font-bold">
                            Amount (USD)
                          </Label>
                          <Input
                            id="usdtAmount"
                            type="number"
                            placeholder="20"
                            min="20"
                            value={usdtAmount}
                            onChange={(e) => setUsdtAmount(e.target.value)}
                            className="bg-white/10 border-blue-600 text-white h-14 text-lg"
                          />
                          <p className="text-blue-300 text-sm mt-2">Minimum deposit: $20 USD</p>
                        </div>

                        <div className="bg-gradient-to-r from-green-500/20 to-green-400/20 p-6 rounded-lg border border-green-500 shadow-lg">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white font-bold text-lg">USDT Address (TRC20):</p>
                              <p className="text-green-400 text-lg font-mono break-all">
                                TABvMMgvfAh4jbNT7dPPJHXVtuEgZUdnUQ
                              </p>
                            </div>
                            <Button
                              size="lg"
                              variant="outline"
                              onClick={() => copyToClipboard("TABvMMgvfAh4jbNT7dPPJHXVtuEgZUdnUQ")}
                              className="text-green-400 border-green-400 hover:bg-green-400 hover:text-black transition-all duration-300"
                            >
                              {copied ? <CheckCircle className="h-6 w-6" /> : <Copy className="h-6 w-6" />}
                            </Button>
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="txHash" className="text-white text-lg font-bold">
                            Transaction Hash (Optional)
                          </Label>
                          <Input
                            id="txHash"
                            placeholder="Enter transaction hash for faster processing"
                            value={usdtTxHash}
                            onChange={(e) => setUsdtTxHash(e.target.value)}
                            className="bg-white/10 border-blue-600 text-white h-14 text-lg"
                          />
                        </div>

                        <Button
                          className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-4 text-lg shadow-xl transition-all duration-300 transform hover:scale-105"
                          onClick={handleUsdtDeposit}
                          disabled={isSubmitting || !usdtAmount}
                        >
                          {isSubmitting ? (
                            <>
                              <Clock className="h-5 w-5 mr-2 animate-spin" />
                              Processing...
                            </>
                          ) : (
                            "I Have Sent USDT"
                          )}
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>

            {/* Bonus Information */}
            <div className="space-y-8">
              <Card className="bg-gradient-to-r from-yellow-400 to-orange-500 border-0 shadow-2xl">
                <CardContent className="p-8">
                  <div className="text-center">
                    <Gift className="h-16 w-16 text-black mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-black mb-3">300% Deposit Bonus</h3>
                    <p className="text-black/80 mb-6 text-lg">Triple your deposit instantly!</p>
                    {amount && Number(amount) >= 200 && (
                      <div className="bg-black/20 p-4 rounded-lg">
                        <p className="text-black text-lg">
                          Your deposit: <strong>KSH {amount}</strong>
                        </p>
                        <p className="text-black text-lg">
                          Bonus: <strong>KSH {calculateBonus(Number(amount)).toLocaleString()}</strong>
                        </p>
                        <p className="text-black font-bold text-xl">
                          Total:{" "}
                          <strong>KSH {(Number(amount) + calculateBonus(Number(amount))).toLocaleString()}</strong>
                        </p>
                      </div>
                    )}
                    {usdtAmount && Number(usdtAmount) >= 20 && (
                      <div className="bg-black/20 p-4 rounded-lg">
                        <p className="text-black text-lg">
                          Your deposit:{" "}
                          <strong>
                            ${usdtAmount} (~KSH {(Number(usdtAmount) * 150).toLocaleString()})
                          </strong>
                        </p>
                        <p className="text-black text-lg">
                          Bonus: <strong>KSH {calculateUSDTBonus(Number(usdtAmount)).toLocaleString()}</strong>
                        </p>
                        <p className="text-black font-bold text-xl">
                          Total:{" "}
                          <strong>
                            KSH {(Number(usdtAmount) * 150 + calculateUSDTBonus(Number(usdtAmount))).toLocaleString()}
                          </strong>
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/10 border-blue-600 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-white text-xl">Deposit Limits</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between text-white">
                    <span className="text-lg">M-Pesa Min:</span>
                    <Badge variant="secondary" className="bg-blue-600 text-lg px-3 py-1">
                      KSH 200
                    </Badge>
                  </div>
                  <div className="flex justify-between text-white">
                    <span className="text-lg">USDT Min:</span>
                    <Badge variant="secondary" className="bg-green-600 text-lg px-3 py-1">
                      $20 USD
                    </Badge>
                  </div>
                  <div className="flex justify-between text-white">
                    <span className="text-lg">Processing Time:</span>
                    <Badge variant="secondary" className="bg-yellow-600 text-lg px-3 py-1">
                      1-10 mins
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <div className="bg-white/5 p-6 rounded-lg border border-blue-600 shadow-xl">
                <h4 className="font-bold text-white mb-3 text-xl">Need Help?</h4>
                <p className="text-blue-300 text-lg mb-4">
                  Having trouble with your deposit? Our support team is here 24/7.
                </p>
                <Button
                  variant="outline"
                  className="w-full text-white border-white hover:bg-white hover:text-blue-800 bg-transparent text-lg py-3 transition-all duration-300"
                >
                  Contact Support
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
