"use client"

export interface DepositRequest {
  userId: number
  amount: number
  method: string
  phoneNumber?: string
  reference: string
  usdAmount?: number
}

export interface PendingDeposit extends DepositRequest {
  id: number
  status: "Pending" | "Approved" | "Rejected"
  timestamp: string
  user: string
}

// Mock deposit storage
let pendingDeposits: PendingDeposit[] = []
let depositIdCounter = 1

export const depositService = {
  submitDeposit: (request: DepositRequest) => {
    const deposit: PendingDeposit = {
      ...request,
      id: depositIdCounter++,
      status: "Pending",
      timestamp: new Date().toISOString(),
      user: `User ${request.userId}`,
    }

    pendingDeposits.push(deposit)

    // Notify admin (in real app, this would be a WebSocket or server notification)
    console.log("🔔 New deposit request:", deposit)

    // Store in localStorage for persistence
    if (typeof window !== "undefined") {
      localStorage.setItem("pendingDeposits", JSON.stringify(pendingDeposits))
    }

    return deposit
  },

  getPendingDeposits: (): PendingDeposit[] => {
    // Load from localStorage on first call
    if (typeof window !== "undefined" && pendingDeposits.length === 0) {
      const stored = localStorage.getItem("pendingDeposits")
      if (stored) {
        pendingDeposits = JSON.parse(stored)
        depositIdCounter = Math.max(...pendingDeposits.map((d) => d.id), 0) + 1
      }
    }
    return pendingDeposits.filter((d) => d.status === "Pending")
  },

  approveDeposit: (depositId: number) => {
    const depositIndex = pendingDeposits.findIndex((d) => d.id === depositId)
    if (depositIndex !== -1) {
      pendingDeposits[depositIndex].status = "Approved"

      // Update localStorage
      if (typeof window !== "undefined") {
        localStorage.setItem("pendingDeposits", JSON.stringify(pendingDeposits))
      }

      return pendingDeposits[depositIndex]
    }
    return null
  },

  rejectDeposit: (depositId: number) => {
    const depositIndex = pendingDeposits.findIndex((d) => d.id === depositId)
    if (depositIndex !== -1) {
      pendingDeposits[depositIndex].status = "Rejected"

      // Update localStorage
      if (typeof window !== "undefined") {
        localStorage.setItem("pendingDeposits", JSON.stringify(pendingDeposits))
      }

      return pendingDeposits[depositIndex]
    }
    return null
  },

  getAllDeposits: () => pendingDeposits,
}
