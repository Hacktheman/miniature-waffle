"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, X } from "lucide-react"

interface WithdrawalSuccessProps {
  amount: number
  method: string
  onClose: () => void
}

export function WithdrawalSuccess({ amount, method, onClose }: WithdrawalSuccessProps) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 border-green-500 shadow-2xl backdrop-blur-sm max-w-sm w-full animate-in zoom-in-95 duration-300">
        <CardContent className="p-6">
          <div className="text-center">
            {/* Close Button */}
            <div className="flex justify-end mb-2">
              <Button size="sm" variant="ghost" onClick={onClose} className="text-white hover:bg-white/20 h-8 w-8 p-0">
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Success Icon */}
            <div className="relative mx-auto w-20 h-20 mb-4">
              <div className="absolute inset-0 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-2 bg-green-900 rounded-full flex items-center justify-center">
                <CheckCircle className="h-10 w-10 text-green-300" />
              </div>
            </div>

            {/* Title */}
            <h3 className="text-2xl font-bold text-white mb-2">Withdrawal Complete!</h3>

            {/* Amount */}
            <div className="bg-white/10 rounded-lg p-4 mb-4 border border-green-500/30">
              <div className="text-green-300 text-3xl font-bold mb-1">KSH {amount.toLocaleString()}</div>
              <p className="text-green-200 text-sm">Successfully sent via {method}</p>
            </div>

            {/* Action Button */}
            <Button
              onClick={onClose}
              className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white font-bold py-3 shadow-xl transition-all duration-300 transform hover:scale-105"
            >
              Continue Betting
            </Button>

            {/* Info */}
            <p className="text-green-300 text-xs mt-3">🎉 Funds will reflect in your account shortly</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
