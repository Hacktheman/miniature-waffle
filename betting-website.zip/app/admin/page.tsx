"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import {
  Trophy,
  Users,
  TrendingUp,
  Plus,
  Minus,
  Check,
  X,
  DollarSign,
  CreditCard,
  Bell,
  Clock,
  Phone,
  MapPin,
  Calendar,
  MessageCircle,
  Send,
  Headphones,
} from "lucide-react"
import { authService } from "@/lib/auth"
import { depositService } from "@/lib/deposit-service"
import { adminAuthService } from "@/lib/admin-auth"
import { chatService } from "@/lib/chat-service"

export default function AdminPage() {
  const router = useRouter()
  const [currentAdmin, setCurrentAdmin] = useState(adminAuthService.getCurrentAdmin())
  const [users, setUsers] = useState(authService.getAllUsers())
  const [pendingDeposits, setPendingDeposits] = useState(depositService.getPendingDeposits())
  const [pendingMessages, setPendingMessages] = useState(chatService.getPendingMessages())
  const [balanceAdjustment, setBalanceAdjustment] = useState({ userId: 0, amount: 0, reason: "" })
  const [adminResponse, setAdminResponse] = useState("")

  useEffect(() => {
    const admin = adminAuthService.getCurrentAdmin()
    if (!admin) {
      router.push("/admin/login")
      return
    }
    setCurrentAdmin(admin)
  }, [router])

  // Real-time updates for users, deposits, and messages
  useEffect(() => {
    const interval = setInterval(() => {
      // Update users list
      const latestUsers = authService.getAllUsers()
      setUsers(latestUsers)

      // Update pending deposits
      const newPendingDeposits = depositService.getPendingDeposits()
      setPendingDeposits(newPendingDeposits)

      // Update pending messages
      const newPendingMessages = chatService.getPendingMessages()
      setPendingMessages(newPendingMessages)
    }, 1000) // Check every second for real-time updates

    // Listen for user updates
    const handleUserUpdate = (event: CustomEvent) => {
      setUsers(event.detail)
    }

    window.addEventListener("userUpdate", handleUserUpdate as EventListener)

    // Listen for new user registrations
    const handleUserRegistration = (event: CustomEvent) => {
      const newUser = event.detail
      setUsers((prevUsers) => {
        const updatedUsers = [...prevUsers, newUser]
        return updatedUsers
      })

      // Show notification for new user
      console.log("🔔 New user registered:", newUser)
    }

    window.addEventListener("userRegistered", handleUserRegistration as EventListener)

    return () => {
      clearInterval(interval)
      window.removeEventListener("userUpdate", handleUserUpdate as EventListener)
      window.removeEventListener("userRegistered", handleUserRegistration as EventListener)
    }
  }, [])

  const adjustUserBalance = (userId: number, amount: number, type: "add" | "deduct") => {
    const user = users.find((u) => u.id === userId)
    if (user) {
      const newBalance = user.balance + (type === "add" ? amount : -amount)
      authService.updateUserBalance(userId, newBalance)

      // Update local state immediately
      setUsers(users.map((u) => (u.id === userId ? { ...u, balance: newBalance } : u)))
    }
  }

  const approveDeposit = (depositId: number) => {
    const deposit = pendingDeposits.find((d) => d.id === depositId)
    if (deposit) {
      // Approve deposit
      depositService.approveDeposit(depositId)

      // Add balance to user (with 300% bonus)
      const bonusAmount = deposit.amount * 3
      const totalAmount = deposit.amount + bonusAmount

      // Find the user and update their balance
      const user = users.find((u) => u.id === deposit.userId)
      if (user) {
        const newBalance = user.balance + totalAmount
        authService.updateUserBalance(deposit.userId, newBalance)

        // Update local users state immediately
        setUsers(users.map((u) => (u.id === deposit.userId ? { ...u, balance: newBalance } : u)))
      }

      // Refresh pending deposits
      setPendingDeposits(depositService.getPendingDeposits())

      // Show success notification
      alert(`✅ Deposit approved successfully!

💰 Amount: KSH ${deposit.amount.toLocaleString()}
🎁 Bonus: KSH ${bonusAmount.toLocaleString()}
💎 Total credited: KSH ${totalAmount.toLocaleString()}

User balance updated in real-time!`)
    }
  }

  const rejectDeposit = (depositId: number) => {
    const deposit = pendingDeposits.find((d) => d.id === depositId)
    if (deposit) {
      depositService.rejectDeposit(depositId)
      setPendingDeposits(depositService.getPendingDeposits())

      alert(`❌ Deposit rejected.

User will be notified to contact support.`)
    }
  }

  const respondToMessage = (messageId: number) => {
    if (!adminResponse.trim()) return

    chatService.respondToMessage(messageId, adminResponse.trim())
    setPendingMessages(chatService.getPendingMessages())
    setAdminResponse("")

    alert("✅ Response sent successfully!")
  }

  const resolveMessage = (messageId: number) => {
    chatService.resolveMessage(messageId)
    setPendingMessages(chatService.getPendingMessages())

    alert("✅ Message marked as resolved!")
  }

  if (!currentAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 flex items-center justify-center">
        <div className="text-white text-xl">Checking authentication...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-800 to-blue-700 border-b border-blue-600 shadow-xl">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Trophy className="h-10 w-10 text-yellow-400" />
              <div>
                <span className="text-3xl font-bold text-white">SportBet Pro</span>
                <div className="text-yellow-400 text-sm font-bold">Admin Dashboard</div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-white font-bold">{currentAdmin.username}</p>
                <p className="text-blue-300 text-sm">{currentAdmin.role}</p>
              </div>
              <div className="relative">
                <Bell className="h-6 w-6 text-white" />
                {(pendingDeposits.length > 0 || pendingMessages.length > 0) && (
                  <div className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold animate-pulse">
                    {pendingDeposits.length + pendingMessages.length}
                  </div>
                )}
              </div>
              <Badge variant="secondary" className="bg-red-600 text-white px-4 py-2 text-lg">
                Admin Panel
              </Badge>
              <Button
                variant="outline"
                className="text-white border-white hover:bg-white hover:text-blue-800 bg-transparent transition-all duration-300"
                onClick={() => {
                  adminAuthService.logout()
                  router.push("/admin/login")
                }}
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-10">
          <Card className="bg-white/10 border-blue-600 backdrop-blur-sm shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-300 text-lg">Total Users</p>
                  <p className="text-white text-3xl font-bold">{users.length}</p>
                  <div className="flex items-center mt-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2"></div>
                    <span className="text-green-400 text-xs">Live Updates</span>
                  </div>
                </div>
                <Users className="h-12 w-12 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 border-blue-600 backdrop-blur-sm shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-300 text-lg">Pending Deposits</p>
                  <p className="text-white text-3xl font-bold">{pendingDeposits.length}</p>
                  {pendingDeposits.length > 0 && (
                    <div className="flex items-center mt-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse mr-2"></div>
                      <span className="text-red-400 text-sm font-bold">Needs Attention</span>
                    </div>
                  )}
                </div>
                <CreditCard className="h-12 w-12 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 border-blue-600 backdrop-blur-sm shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-300 text-lg">Support Messages</p>
                  <p className="text-white text-3xl font-bold">{pendingMessages.length}</p>
                  {pendingMessages.length > 0 && (
                    <div className="flex items-center mt-2">
                      <div className="w-3 h-3 bg-orange-500 rounded-full animate-pulse mr-2"></div>
                      <span className="text-orange-400 text-sm font-bold">New Messages</span>
                    </div>
                  )}
                </div>
                <MessageCircle className="h-12 w-12 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 border-blue-600 backdrop-blur-sm shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-300 text-lg">Total Balance</p>
                  <p className="text-white text-3xl font-bold">
                    KSH {users.reduce((sum, user) => sum + user.balance, 0).toLocaleString()}
                  </p>
                  <div className="flex items-center mt-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2"></div>
                    <span className="text-green-400 text-xs">Real-time</span>
                  </div>
                </div>
                <DollarSign className="h-12 w-12 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 border-blue-600 backdrop-blur-sm shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-300 text-lg">Active Users</p>
                  <p className="text-white text-3xl font-bold">{users.filter((u) => u.status === "Active").length}</p>
                </div>
                <TrendingUp className="h-12 w-12 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="deposits" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-blue-700 shadow-lg">
            <TabsTrigger value="deposits" className="data-[state=active]:bg-blue-600 font-bold text-lg">
              Deposit Approvals{" "}
              {pendingDeposits.length > 0 && <Badge className="ml-2 bg-red-600">{pendingDeposits.length}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="support" className="data-[state=active]:bg-blue-600 font-bold text-lg">
              Customer Support{" "}
              {pendingMessages.length > 0 && <Badge className="ml-2 bg-orange-600">{pendingMessages.length}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-blue-600 font-bold text-lg">
              User Management ({users.length})
            </TabsTrigger>
            <TabsTrigger value="transactions" className="data-[state=active]:bg-blue-600 font-bold text-lg">
              All Transactions
            </TabsTrigger>
          </TabsList>

          <TabsContent value="deposits" className="space-y-6">
            <Card className="bg-white/10 border-blue-600 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="text-white text-2xl flex items-center">
                  <Clock className="h-6 w-6 mr-3" />
                  Pending Deposits
                  {pendingDeposits.length > 0 && (
                    <Badge className="ml-3 bg-red-600 text-white animate-pulse px-4 py-2 text-lg">NEW</Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {pendingDeposits.length === 0 ? (
                    <div className="text-center py-12">
                      <Clock className="h-16 w-16 text-blue-400 mx-auto mb-4" />
                      <p className="text-blue-300 text-xl">No pending deposits</p>
                      <p className="text-blue-400">All deposits have been processed</p>
                    </div>
                  ) : (
                    pendingDeposits.map((deposit) => {
                      const user = users.find((u) => u.id === deposit.userId)
                      return (
                        <Card
                          key={deposit.id}
                          className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-500 shadow-lg"
                        >
                          <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <div className="flex items-center space-x-4">
                                  <div>
                                    <p className="text-white font-bold text-xl">{deposit.user}</p>
                                    <div className="flex items-center space-x-2 mb-2">
                                      <Phone className="h-4 w-4 text-blue-400" />
                                      <span className="text-blue-300">{user?.phone || deposit.phoneNumber}</span>
                                    </div>
                                    <p className="text-yellow-300 text-lg">
                                      {deposit.method} - {deposit.reference}
                                    </p>
                                    <p className="text-blue-300 text-sm">
                                      {new Date(deposit.timestamp).toLocaleString()}
                                    </p>
                                  </div>
                                  <Badge className="bg-yellow-600 text-white animate-pulse px-4 py-2 text-lg">
                                    NEW
                                  </Badge>
                                </div>
                              </div>
                              <div className="flex items-center space-x-6">
                                <div className="text-right">
                                  <p className="text-white font-bold text-2xl">KSH {deposit.amount.toLocaleString()}</p>
                                  <p className="text-yellow-400 text-lg">
                                    +{(deposit.amount * 3).toLocaleString()} Bonus
                                  </p>
                                  <p className="text-green-400 text-xl font-bold">
                                    Total: KSH {(deposit.amount + deposit.amount * 3).toLocaleString()}
                                  </p>
                                </div>
                                <div className="flex space-x-3">
                                  <Button
                                    size="lg"
                                    className="bg-green-600 hover:bg-green-700 px-6 py-3 text-lg font-bold shadow-xl transition-all duration-300 transform hover:scale-105"
                                    onClick={() => approveDeposit(deposit.id)}
                                  >
                                    <Check className="h-5 w-5 mr-2" />
                                    Approve
                                  </Button>
                                  <Button
                                    size="lg"
                                    variant="destructive"
                                    className="px-6 py-3 text-lg font-bold shadow-xl transition-all duration-300 transform hover:scale-105"
                                    onClick={() => rejectDeposit(deposit.id)}
                                  >
                                    <X className="h-5 w-5 mr-2" />
                                    Reject
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="support" className="space-y-6">
            <Card className="bg-white/10 border-blue-600 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="text-white text-2xl flex items-center">
                  <Headphones className="h-6 w-6 mr-3" />
                  Customer Support Messages
                  {pendingMessages.length > 0 && (
                    <Badge className="ml-3 bg-orange-600 text-white animate-pulse px-4 py-2 text-lg">
                      {pendingMessages.length} NEW
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {pendingMessages.length === 0 ? (
                    <div className="text-center py-12">
                      <MessageCircle className="h-16 w-16 text-blue-400 mx-auto mb-4" />
                      <p className="text-blue-300 text-xl">No pending messages</p>
                      <p className="text-blue-400">All customer inquiries have been handled</p>
                    </div>
                  ) : (
                    pendingMessages.map((message) => (
                      <Card
                        key={message.id}
                        className="bg-gradient-to-r from-orange-500/20 to-red-500/20 border-orange-500 shadow-lg"
                      >
                        <CardContent className="p-6">
                          <div className="space-y-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4">
                                <div>
                                  <p className="text-white font-bold text-xl">{message.userName}</p>
                                  <div className="flex items-center space-x-2 mb-2">
                                    <Phone className="h-4 w-4 text-blue-400" />
                                    <span className="text-blue-300">{message.userPhone}</span>
                                  </div>
                                  <p className="text-orange-300 text-sm">
                                    {new Date(message.timestamp).toLocaleString()}
                                  </p>
                                </div>
                                <Badge className="bg-orange-600 text-white animate-pulse px-4 py-2 text-lg">NEW</Badge>
                              </div>
                            </div>

                            <div className="bg-white/10 p-4 rounded-lg border border-orange-500/30">
                              <p className="text-white text-lg">{message.message}</p>
                            </div>

                            <div className="space-y-3">
                              <Label htmlFor={`response-${message.id}`} className="text-white text-lg font-bold">
                                Admin Response
                              </Label>
                              <Textarea
                                id={`response-${message.id}`}
                                placeholder="Type your response to the customer..."
                                value={adminResponse}
                                onChange={(e) => setAdminResponse(e.target.value)}
                                className="bg-white/10 border-blue-600 text-white resize-none h-24"
                              />
                              <div className="flex space-x-3">
                                <Button
                                  size="lg"
                                  className="bg-blue-600 hover:bg-blue-700 px-6 py-3 text-lg font-bold shadow-xl transition-all duration-300 transform hover:scale-105"
                                  onClick={() => respondToMessage(message.id)}
                                  disabled={!adminResponse.trim()}
                                >
                                  <Send className="h-5 w-5 mr-2" />
                                  Send Response
                                </Button>
                                <Button
                                  size="lg"
                                  variant="outline"
                                  className="text-white border-white hover:bg-white hover:text-blue-800 px-6 py-3 text-lg font-bold bg-transparent"
                                  onClick={() => resolveMessage(message.id)}
                                >
                                  <Check className="h-5 w-5 mr-2" />
                                  Mark Resolved
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card className="bg-white/10 border-blue-600 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="text-white text-2xl flex items-center">
                  <Users className="h-6 w-6 mr-3" />
                  User Management - Real Time ({users.length} Users)
                  <div className="ml-3 flex items-center">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2"></div>
                    <span className="text-green-400 text-sm">Live</span>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {users.map((user) => (
                    <Card key={user.id} className="bg-white/5 border-blue-600 shadow-lg">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-4">
                              <div>
                                <p className="text-white font-bold text-xl">
                                  {user.firstName} {user.lastName}
                                </p>
                                <div className="flex items-center space-x-4 mt-2">
                                  <div className="flex items-center space-x-2">
                                    <Phone className="h-4 w-4 text-blue-400" />
                                    <span className="text-blue-300 font-bold">{user.phone}</span>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <MapPin className="h-4 w-4 text-green-400" />
                                    <span className="text-green-300">{user.country}</span>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <Calendar className="h-4 w-4 text-purple-400" />
                                    <span className="text-purple-300">{user.joined}</span>
                                  </div>
                                </div>
                                <p className="text-blue-400 text-sm mt-1">User ID: #{user.id}</p>
                              </div>
                              <Badge
                                variant={user.status === "Active" ? "secondary" : "destructive"}
                                className={`${user.status === "Active" ? "bg-blue-600" : "bg-red-600"} text-lg px-4 py-2`}
                              >
                                {user.status}
                              </Badge>
                            </div>
                          </div>
                          <div className="flex items-center space-x-6">
                            <div className="text-right">
                              <p className="text-white font-bold text-2xl">KSH {user.balance.toLocaleString()}</p>
                              <p className="text-blue-300 text-lg">Current Balance</p>
                              <div className="flex items-center justify-end mt-1">
                                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2"></div>
                                <span className="text-green-400 text-xs">Real-time</span>
                              </div>
                            </div>
                            <div className="flex space-x-3">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700 px-6 py-3 shadow-xl">
                                    <Plus className="h-5 w-5" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-md bg-gradient-to-br from-blue-900/95 to-indigo-900/95 border-blue-500">
                                  <DialogHeader>
                                    <DialogTitle className="text-xl text-white">
                                      Add Balance - {user.firstName} {user.lastName}
                                    </DialogTitle>
                                  </DialogHeader>
                                  <div className="space-y-6">
                                    <div>
                                      <Label htmlFor="addAmount" className="text-lg text-white">
                                        Amount (KSH)
                                      </Label>
                                      <Input
                                        id="addAmount"
                                        type="number"
                                        placeholder="1000"
                                        className="h-12 text-lg bg-white/10 border-blue-600 text-white"
                                        onChange={(e) =>
                                          setBalanceAdjustment({
                                            ...balanceAdjustment,
                                            amount: Number(e.target.value),
                                            userId: user.id,
                                          })
                                        }
                                      />
                                    </div>
                                    <div>
                                      <Label htmlFor="reason" className="text-lg text-white">
                                        Reason
                                      </Label>
                                      <Input
                                        id="reason"
                                        placeholder="Bonus, correction, etc."
                                        className="h-12 text-lg bg-white/10 border-blue-600 text-white"
                                        onChange={(e) =>
                                          setBalanceAdjustment({ ...balanceAdjustment, reason: e.target.value })
                                        }
                                      />
                                    </div>
                                    <Button
                                      className="w-full bg-blue-600 hover:bg-blue-700 py-3 text-lg"
                                      onClick={() => {
                                        adjustUserBalance(user.id, balanceAdjustment.amount, "add")
                                        setBalanceAdjustment({ userId: 0, amount: 0, reason: "" })
                                      }}
                                    >
                                      Add Balance
                                    </Button>
                                  </div>
                                </DialogContent>
                              </Dialog>

                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button size="lg" variant="destructive" className="px-6 py-3 shadow-xl">
                                    <Minus className="h-5 w-5" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-md bg-gradient-to-br from-blue-900/95 to-indigo-900/95 border-blue-500">
                                  <DialogHeader>
                                    <DialogTitle className="text-xl text-white">
                                      Deduct Balance - {user.firstName} {user.lastName}
                                    </DialogTitle>
                                  </DialogHeader>
                                  <div className="space-y-6">
                                    <div>
                                      <Label htmlFor="deductAmount" className="text-lg text-white">
                                        Amount (KSH)
                                      </Label>
                                      <Input
                                        id="deductAmount"
                                        type="number"
                                        placeholder="500"
                                        max={user.balance}
                                        className="h-12 text-lg bg-white/10 border-blue-600 text-white"
                                        onChange={(e) =>
                                          setBalanceAdjustment({
                                            ...balanceAdjustment,
                                            amount: Number(e.target.value),
                                            userId: user.id,
                                          })
                                        }
                                      />
                                    </div>
                                    <div>
                                      <Label htmlFor="deductReason" className="text-lg text-white">
                                        Reason
                                      </Label>
                                      <Input
                                        id="deductReason"
                                        placeholder="Penalty, correction, etc."
                                        className="h-12 text-lg bg-white/10 border-blue-600 text-white"
                                        onChange={(e) =>
                                          setBalanceAdjustment({ ...balanceAdjustment, reason: e.target.value })
                                        }
                                      />
                                    </div>
                                    <Button
                                      className="w-full bg-red-600 hover:bg-red-700 py-3 text-lg"
                                      onClick={() => {
                                        adjustUserBalance(user.id, balanceAdjustment.amount, "deduct")
                                        setBalanceAdjustment({ userId: 0, amount: 0, reason: "" })
                                      }}
                                    >
                                      Deduct Balance
                                    </Button>
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-6">
            <Card className="bg-white/10 border-blue-600 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="text-white text-2xl">All Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {depositService.getAllDeposits().map((deposit) => {
                    const user = users.find((u) => u.id === deposit.userId)
                    return (
                      <Card key={deposit.id} className="bg-white/5 border-blue-600 shadow-lg">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-4">
                                <div>
                                  <p className="text-white font-bold text-lg">{deposit.user}</p>
                                  <div className="flex items-center space-x-2 mb-1">
                                    <Phone className="h-4 w-4 text-blue-400" />
                                    <span className="text-blue-300">{user?.phone || "N/A"}</span>
                                  </div>
                                  <p className="text-blue-300">{deposit.method} Deposit</p>
                                  <p className="text-blue-300 text-sm">
                                    {new Date(deposit.timestamp).toLocaleString()}
                                  </p>
                                </div>
                                <Badge
                                  variant={
                                    deposit.status === "Approved"
                                      ? "secondary"
                                      : deposit.status === "Pending"
                                        ? "default"
                                        : "destructive"
                                  }
                                  className={`text-lg px-4 py-2 ${
                                    deposit.status === "Approved"
                                      ? "bg-green-600"
                                      : deposit.status === "Pending"
                                        ? "bg-yellow-600"
                                        : "bg-red-600"
                                  }`}
                                >
                                  {deposit.status}
                                </Badge>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-white font-bold text-2xl">KSH {deposit.amount.toLocaleString()}</p>
                              <p className="text-blue-300">{deposit.reference}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
