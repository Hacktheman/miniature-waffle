"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Wallet } from "lucide-react"
import { authService } from "@/lib/auth"

interface BalanceWidgetProps {
  balance: number
  isLoggedIn: boolean
}

export function BalanceWidget({ balance, isLoggedIn }: BalanceWidgetProps) {
  const [currentBalance, setCurrentBalance] = useState(balance)

  // Update balance when prop changes
  useEffect(() => {
    setCurrentBalance(balance)
  }, [balance])

  // Listen for real-time balance updates
  useEffect(() => {
    const handleBalanceUpdate = (event: CustomEvent) => {
      const updatedUser = event.detail
      setCurrentBalance(updatedUser.balance)
    }

    window.addEventListener("balanceUpdate", handleBalanceUpdate as EventListener)

    // Also check for updates periodically
    const interval = setInterval(() => {
      const currentUser = authService.getCurrentUser()
      if (currentUser && currentUser.balance !== currentBalance) {
        setCurrentBalance(currentUser.balance)
      }
    }, 1000)

    return () => {
      window.removeEventListener("balanceUpdate", handleBalanceUpdate as EventListener)
      clearInterval(interval)
    }
  }, [currentBalance])

  if (!isLoggedIn) return null

  return (
    <Card className="bg-gradient-to-r from-blue-600 to-blue-700 border-blue-500 shadow-lg">
      <CardContent className="p-3">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Wallet className="h-6 w-6 text-yellow-400" />
          </div>
          <div>
            <p className="text-blue-100 text-xs">Balance</p>
            <p className="text-white font-bold text-lg">KSH {currentBalance.toFixed(2)}</p>
          </div>
          <div className="flex items-center">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
