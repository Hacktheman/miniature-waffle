"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Trophy, Clock, Gift, Zap, Gamepad2, Star, LogIn, Sparkles, MessageCircle, Headphones } from "lucide-react"
import Link from "next/link"
import { footballMatches, rugbyMatches, cricketMatches, tennisMatches } from "@/data/sports-data"
import { bettingMarkets, liveMatches, casinoGames } from "@/data/betting-markets"
import { BalanceWidget } from "@/components/balance-widget"
import { BetSlip } from "@/components/bet-slip"
import { CustomerChat } from "@/components/customer-chat"
import { authService } from "@/lib/auth"

export default function HomePage() {
  const [selectedBets, setSelectedBets] = useState<any[]>([])
  const [currentUser, setCurrentUser] = useState(authService.getCurrentUser())
  const [loginData, setLoginData] = useState({ phone: "", password: "" })
  const [expandedMatch, setExpandedMatch] = useState<number | null>(null)
  const [showChat, setShowChat] = useState(false)

  useEffect(() => {
    // Check for logged in user on component mount
    const user = authService.getCurrentUser()
    setCurrentUser(user)

    // Listen for balance updates
    const handleBalanceUpdate = (event: CustomEvent) => {
      const updatedUser = event.detail
      setCurrentUser(updatedUser)
    }

    window.addEventListener("balanceUpdate", handleBalanceUpdate as EventListener)

    // Check for user updates periodically
    const interval = setInterval(() => {
      const latestUser = authService.getCurrentUser()
      if (latestUser && (!currentUser || latestUser.balance !== currentUser.balance)) {
        setCurrentUser(latestUser)
      }
    }, 1000)

    return () => {
      window.removeEventListener("balanceUpdate", handleBalanceUpdate as EventListener)
      clearInterval(interval)
    }
  }, [currentUser])

  const handleLogin = () => {
    if (loginData.phone && loginData.password) {
      const user = authService.login(loginData.phone, loginData.password)
      if (user) {
        setCurrentUser(user)
        setLoginData({ phone: "", password: "" })
      } else {
        alert("Invalid credentials")
      }
    }
  }

  const addToBetSlip = (bet: any) => {
    setSelectedBets([...selectedBets, bet])
  }

  const removeBet = (index: number) => {
    setSelectedBets(selectedBets.filter((_, i) => i !== index))
  }

  const clearAllBets = () => {
    setSelectedBets([])
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      {/* Customer Chat */}
      <CustomerChat isOpen={showChat} onClose={() => setShowChat(false)} />

      {/* Floating Chat Button */}
      {currentUser && !showChat && (
        <Button
          className="fixed bottom-6 right-6 z-40 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-2xl rounded-full w-16 h-16 p-0 transition-all duration-300 transform hover:scale-110"
          onClick={() => setShowChat(true)}
        >
          <div className="relative">
            <MessageCircle className="h-8 w-8" />
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
          </div>
        </Button>
      )}

      {/* Header */}
      <header className="bg-gradient-to-r from-blue-800 to-blue-700 border-b border-blue-500 sticky top-0 z-50 shadow-xl">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Trophy className="h-10 w-10 text-yellow-400" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-400 rounded-full animate-pulse"></div>
                </div>
                <div>
                  <span className="text-3xl font-bold text-white">SportBet Pro</span>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-yellow-400 text-sm ml-1">5.0</span>
                  </div>
                </div>
              </div>
              <nav className="hidden md:flex space-x-8">
                <Link href="/" className="text-white hover:text-yellow-400 transition-all duration-300 font-medium">
                  Sports
                </Link>
                <Link href="#live" className="text-white hover:text-yellow-400 transition-all duration-300 font-medium">
                  <Zap className="h-4 w-4 inline mr-1" />
                  Live Betting
                </Link>
                <Link
                  href="#casino"
                  className="text-white hover:text-yellow-400 transition-all duration-300 font-medium"
                >
                  <Gamepad2 className="h-4 w-4 inline mr-1" />
                  Casino
                </Link>
                <Link
                  href="/promotions"
                  className="text-white hover:text-yellow-400 transition-all duration-300 font-medium"
                >
                  Promotions
                </Link>
                {currentUser && (
                  <Button
                    variant="ghost"
                    className="text-white hover:text-yellow-400 transition-all duration-300 font-medium p-0 h-auto"
                    onClick={() => setShowChat(true)}
                  >
                    <Headphones className="h-4 w-4 inline mr-1" />
                    Support
                  </Button>
                )}
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              {!currentUser ? (
                <div className="flex space-x-3">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:from-purple-600 hover:via-pink-600 hover:to-red-600 text-white font-bold shadow-lg transition-all duration-300 transform hover:scale-105 relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 opacity-0 hover:opacity-20 transition-opacity duration-300"></div>
                        <LogIn className="h-4 w-4 mr-2" />
                        <span className="relative z-10">Login</span>
                        <Sparkles className="h-4 w-4 ml-2 animate-pulse" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md bg-gradient-to-br from-blue-900/95 to-indigo-900/95 border-blue-500 backdrop-blur-sm">
                      <DialogHeader>
                        <DialogTitle className="text-white text-xl">Login to SportBet Pro</DialogTitle>
                        <DialogDescription className="text-blue-300">
                          Enter your credentials to access your account
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-6">
                        <div>
                          <Label htmlFor="phone" className="text-white font-bold">
                            Phone Number
                          </Label>
                          <Input
                            id="phone"
                            placeholder="0712345678"
                            value={loginData.phone}
                            onChange={(e) => setLoginData({ ...loginData, phone: e.target.value })}
                            className="bg-white/10 border-blue-600 text-white h-12 text-lg"
                          />
                        </div>
                        <div>
                          <Label htmlFor="password" className="text-white font-bold">
                            Password
                          </Label>
                          <Input
                            id="password"
                            type="password"
                            value={loginData.password}
                            onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                            className="bg-white/10 border-blue-600 text-white h-12 text-lg"
                          />
                        </div>
                        <Button
                          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3 text-lg shadow-xl transition-all duration-300 transform hover:scale-105"
                          onClick={handleLogin}
                        >
                          <LogIn className="h-5 w-5 mr-2" />
                          Login Now
                        </Button>
                      </div>
                      <p className="text-sm text-center text-blue-300">
                        Don't have an account?{" "}
                        <Link href="/register" className="text-yellow-400 hover:underline font-bold">
                          Sign up here
                        </Link>
                      </p>
                    </DialogContent>
                  </Dialog>
                  <Link href="/register">
                    <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-semibold shadow-lg transition-all duration-300 transform hover:scale-105">
                      Register Now
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="flex items-center space-x-4">
                  <BalanceWidget balance={currentUser.balance} isLoggedIn={!!currentUser} />
                  <Link href="/deposit">
                    <Button className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg transition-all duration-300 transform hover:scale-105">
                      Deposit
                    </Button>
                  </Link>
                  <Link href="/withdraw">
                    <Button
                      variant="outline"
                      className="text-white border-white hover:bg-white hover:text-blue-800 bg-transparent transition-all duration-300"
                    >
                      Withdraw
                    </Button>
                  </Link>
                  <Button
                    variant="outline"
                    className="text-white border-white hover:bg-white hover:text-blue-800 bg-transparent transition-all duration-300"
                    onClick={() => {
                      authService.logout()
                      setCurrentUser(null)
                    }}
                  >
                    Logout
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Hero Section */}
            <div className="mb-8">
              <Card className="bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 border-0 shadow-2xl overflow-hidden">
                <CardContent className="p-8 relative">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                  <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-4xl font-bold text-black mb-3">300% Welcome Bonus!</h1>
                        <p className="text-black/80 text-lg mb-4">Get up to KSH 30,000 bonus on your first deposit</p>
                        <div className="flex items-center space-x-4">
                          <Badge className="bg-black/20 text-black font-bold px-4 py-2">✓ Withdrawable</Badge>
                          <Badge className="bg-black/20 text-black font-bold px-4 py-2">✓ Instant</Badge>
                          <Badge className="bg-black/20 text-black font-bold px-4 py-2">✓ No Wagering</Badge>
                        </div>
                      </div>
                      <div className="hidden md:block">
                        <Gift className="h-24 w-24 text-black/30" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Live Betting Section */}
            <Card className="mb-8 bg-gradient-to-r from-gray-800/90 to-gray-700/90 border-red-500 shadow-xl" id="live">
              <CardHeader>
                <CardTitle className="text-white flex items-center text-2xl">
                  <Zap className="h-8 w-8 mr-3 text-yellow-400" />
                  Live Betting
                  <Badge className="ml-3 bg-red-600 text-white animate-pulse px-3 py-1">LIVE</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {liveMatches.map((match) => (
                  <Card
                    key={match.id}
                    className="bg-white/10 border-red-500 shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-4 md:space-y-0">
                        <div className="flex-1 w-full">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-2 md:space-x-4">
                              <span className="text-white font-bold text-base md:text-lg">{match.home}</span>
                              <Badge className="bg-red-600 text-white animate-pulse text-xs md:text-sm px-2 py-1">
                                {match.time}
                              </Badge>
                            </div>
                            <div className="text-center">
                              <div className="text-yellow-400 font-bold text-xl md:text-2xl">{match.score}</div>
                            </div>
                          </div>
                          <div className="text-white font-bold text-base md:text-lg mb-3">{match.away}</div>
                          <div className="flex flex-wrap gap-1 md:gap-2">
                            {match.events.slice(-3).map((event, idx) => (
                              <Badge
                                key={idx}
                                variant="outline"
                                className={`text-xs ${
                                  event.event === "GOAL"
                                    ? "border-green-500 text-green-400"
                                    : event.event === "YELLOW"
                                      ? "border-yellow-500 text-yellow-400"
                                      : event.event === "RED"
                                        ? "border-red-500 text-red-400"
                                        : "border-blue-500 text-blue-400"
                                }`}
                              >
                                {event.time}' {event.event}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex space-x-2 md:space-x-3 w-full md:w-auto md:ml-6">
                          <Button
                            size="sm"
                            className="bg-red-600 hover:bg-red-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                            onClick={() =>
                              addToBetSlip({
                                match: `${match.home} vs ${match.away} (LIVE)`,
                                bet: "1",
                                odds: match.odds["1"],
                              })
                            }
                          >
                            1<br />
                            {match.odds["1"]}
                          </Button>
                          <Button
                            size="sm"
                            className="bg-red-600 hover:bg-red-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                            onClick={() =>
                              addToBetSlip({
                                match: `${match.home} vs ${match.away} (LIVE)`,
                                bet: "X",
                                odds: match.odds["X"],
                              })
                            }
                          >
                            X<br />
                            {match.odds["X"]}
                          </Button>
                          <Button
                            size="sm"
                            className="bg-red-600 hover:bg-red-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                            onClick={() =>
                              addToBetSlip({
                                match: `${match.home} vs ${match.away} (LIVE)`,
                                bet: "2",
                                odds: match.odds["2"],
                              })
                            }
                          >
                            2<br />
                            {match.odds["2"]}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>

            {/* Casino Section */}
            <Card
              className="mb-8 bg-gradient-to-r from-purple-600/20 to-purple-500/20 border-purple-500 shadow-xl"
              id="casino"
            >
              <CardHeader>
                <CardTitle className="text-white flex items-center text-2xl">
                  <Gamepad2 className="h-8 w-8 mr-3 text-purple-400" />
                  Live Casino
                  <Badge className="ml-3 bg-purple-600 text-white px-3 py-1">HOT</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  {casinoGames.map((game) => (
                    <Card
                      key={game.id}
                      className="bg-white/10 border-purple-500 hover:bg-white/20 transition-all duration-300 cursor-pointer shadow-lg hover:shadow-xl transform hover:scale-105"
                    >
                      <CardContent className="p-4">
                        <div className="aspect-video bg-gradient-to-br from-purple-600 to-purple-800 rounded-lg mb-3 overflow-hidden shadow-lg">
                          <img
                            src={game.thumbnail || "/placeholder.svg"}
                            alt={game.name}
                            className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                            onError={(e) => {
                              e.currentTarget.src = "/placeholder.svg?height=200&width=300"
                            }}
                          />
                        </div>
                        <h4 className="text-white font-bold text-sm mb-2">{game.name}</h4>
                        <p className="text-purple-300 text-xs mb-3">{game.provider}</p>
                        <div className="flex items-center justify-between">
                          <Badge variant="outline" className="border-purple-500 text-purple-400 text-xs">
                            {game.type}
                          </Badge>
                          <div className="flex items-center space-x-1">
                            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                            <span className="text-green-400 text-xs font-bold">{game.players}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Sports Tabs */}
            <Tabs defaultValue="football" className="w-full">
              <TabsList className="grid w-full grid-cols-4 bg-gradient-to-r from-blue-700 to-blue-600 shadow-lg">
                <TabsTrigger value="football" className="data-[state=active]:bg-blue-600 font-bold text-xs md:text-sm">
                  ⚽ Football
                </TabsTrigger>
                <TabsTrigger value="rugby" className="data-[state=active]:bg-blue-600 font-bold text-xs md:text-sm">
                  🏉 Rugby
                </TabsTrigger>
                <TabsTrigger value="cricket" className="data-[state=active]:bg-blue-600 font-bold text-xs md:text-sm">
                  🏏 Cricket
                </TabsTrigger>
                <TabsTrigger value="tennis" className="data-[state=active]:bg-blue-600 font-bold text-xs md:text-sm">
                  🎾 Tennis
                </TabsTrigger>
              </TabsList>

              <TabsContent value="football" className="space-y-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-white">Premier League</h3>
                  <Badge variant="secondary" className="bg-green-600 text-white px-4 py-2">
                    <Clock className="h-4 w-4 mr-2" />
                    Today's Matches
                  </Badge>
                </div>

                {/* Football Matches with expanded markets */}
                {footballMatches.slice(0, 10).map((match, index) => (
                  <Card
                    key={index}
                    className="bg-white/10 border-blue-600 shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4 md:mb-6 space-y-4 md:space-y-0">
                        <div className="flex-1 w-full">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-white font-bold text-base md:text-lg">{match.home}</span>
                            <div className="text-right">
                              <span className="text-blue-300 text-base md:text-lg font-bold">{match.time}</span>
                              <p className="text-blue-400 text-xs md:text-sm">{match.league}</p>
                            </div>
                          </div>
                          <div className="text-white font-bold text-base md:text-lg">{match.away}</div>
                        </div>
                        <div className="flex space-x-2 md:space-x-3 w-full md:w-auto md:ml-6">
                          <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                            onClick={() =>
                              addToBetSlip({ match: `${match.home} vs ${match.away}`, bet: "1", odds: match.odds["1"] })
                            }
                          >
                            1<br />
                            {match.odds["1"]}
                          </Button>
                          <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                            onClick={() =>
                              addToBetSlip({ match: `${match.home} vs ${match.away}`, bet: "X", odds: match.odds["X"] })
                            }
                          >
                            X<br />
                            {match.odds["X"]}
                          </Button>
                          <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                            onClick={() =>
                              addToBetSlip({ match: `${match.home} vs ${match.away}`, bet: "2", odds: match.odds["2"] })
                            }
                          >
                            2<br />
                            {match.odds["2"]}
                          </Button>
                        </div>
                      </div>

                      {/* Expandable Markets */}
                      <div className="border-t border-blue-600 pt-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-blue-300 hover:text-white mb-4 font-bold text-sm md:text-base"
                          onClick={() => setExpandedMatch(expandedMatch === index ? null : index)}
                        >
                          {expandedMatch === index ? "Hide Markets" : "Show More Markets"} (+15)
                        </Button>

                        {expandedMatch === index && (
                          <div className="space-y-6">
                            {/* Correct Score */}
                            <div>
                              <h4 className="text-white font-bold mb-3 text-base md:text-lg">Correct Score</h4>
                              <div className="grid grid-cols-3 gap-2 md:gap-3">
                                {bettingMarkets.football.correctScores.slice(0, 9).map((score) => (
                                  <Button
                                    key={score.score}
                                    size="sm"
                                    variant="outline"
                                    className="border-blue-600 text-white hover:bg-blue-600 bg-transparent h-12 md:h-16 font-bold shadow-lg transition-all duration-300 transform hover:scale-105 text-xs md:text-sm"
                                    onClick={() =>
                                      addToBetSlip({
                                        match: `${match.home} vs ${match.away}`,
                                        bet: `Correct Score ${score.score}`,
                                        odds: score.odds,
                                      })
                                    }
                                  >
                                    {score.score}
                                    <br />
                                    {score.odds}
                                  </Button>
                                ))}
                              </div>
                            </div>

                            {/* Over/Under Goals */}
                            <div>
                              <h4 className="text-white font-bold mb-3 text-base md:text-lg">Total Goals</h4>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
                                {bettingMarkets.football.goalMarkets.map((goal) => (
                                  <Button
                                    key={goal.market}
                                    size="sm"
                                    variant="outline"
                                    className="border-blue-600 text-white hover:bg-blue-600 bg-transparent h-12 md:h-16 font-bold shadow-lg transition-all duration-300 transform hover:scale-105 text-xs md:text-sm"
                                    onClick={() =>
                                      addToBetSlip({
                                        match: `${match.home} vs ${match.away}`,
                                        bet: goal.market,
                                        odds: goal.odds,
                                      })
                                    }
                                  >
                                    {goal.market}
                                    <br />
                                    {goal.odds}
                                  </Button>
                                ))}
                              </div>
                            </div>

                            {/* Half Time/Full Time */}
                            <div>
                              <h4 className="text-white font-bold mb-3 text-base md:text-lg">Half Time / Full Time</h4>
                              <div className="grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-3">
                                {bettingMarkets.football.halfTimeMarkets.slice(0, 6).map((ht) => (
                                  <Button
                                    key={ht.market}
                                    size="sm"
                                    variant="outline"
                                    className="border-blue-600 text-white hover:bg-blue-600 bg-transparent h-12 md:h-16 font-bold shadow-lg transition-all duration-300 transform hover:scale-105 text-xs md:text-sm"
                                    onClick={() =>
                                      addToBetSlip({
                                        match: `${match.home} vs ${match.away}`,
                                        bet: ht.market,
                                        odds: ht.odds,
                                      })
                                    }
                                  >
                                    {ht.market}
                                    <br />
                                    {ht.odds}
                                  </Button>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="rugby" className="space-y-6">
                <h3 className="text-2xl font-bold text-white mb-6">Rugby Championship</h3>
                {rugbyMatches.slice(0, 8).map((match, index) => (
                  <Card
                    key={index}
                    className="bg-white/10 border-blue-600 shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-4 md:space-y-0">
                        <div className="flex-1 w-full">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-white font-bold text-base md:text-lg">{match.home}</span>
                            <div className="text-right">
                              <span className="text-blue-300 text-base md:text-lg font-bold">{match.time}</span>
                              <p className="text-blue-400 text-xs md:text-sm">{match.league}</p>
                            </div>
                          </div>
                          <div className="text-white font-bold text-base md:text-lg">{match.away}</div>
                        </div>
                        <div className="flex space-x-2 md:space-x-3 w-full md:w-auto md:ml-6">
                          <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                          >
                            1<br />
                            {match.odds["1"]}
                          </Button>
                          {match.odds["X"] && (
                            <Button
                              size="sm"
                              className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                            >
                              X<br />
                              {match.odds["X"]}
                            </Button>
                          )}
                          <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                          >
                            2<br />
                            {match.odds["2"]}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="cricket" className="space-y-6">
                <h3 className="text-2xl font-bold text-white mb-6">T20 World Cup</h3>
                {cricketMatches.slice(0, 8).map((match, index) => (
                  <Card
                    key={index}
                    className="bg-white/10 border-blue-600 shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-4 md:space-y-0">
                        <div className="flex-1 w-full">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-white font-bold text-base md:text-lg">{match.home}</span>
                            <div className="text-right">
                              <span className="text-blue-300 text-base md:text-lg font-bold">{match.time}</span>
                              <p className="text-blue-400 text-xs md:text-sm">
                                {match.format} - {match.series}
                              </p>
                            </div>
                          </div>
                          <div className="text-white font-bold text-base md:text-lg">{match.away}</div>
                        </div>
                        <div className="flex space-x-2 md:space-x-3 w-full md:w-auto md:ml-6">
                          <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                          >
                            1<br />
                            {match.odds["1"]}
                          </Button>
                          {match.odds["Draw"] && (
                            <Button
                              size="sm"
                              className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                            >
                              Draw
                              <br />
                              {match.odds["Draw"]}
                            </Button>
                          )}
                          <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                          >
                            2<br />
                            {match.odds["2"]}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="tennis" className="space-y-6">
                <h3 className="text-2xl font-bold text-white mb-6">ATP Masters</h3>
                {tennisMatches.slice(0, 8).map((match, index) => (
                  <Card
                    key={index}
                    className="bg-white/10 border-blue-600 shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-4 md:space-y-0">
                        <div className="flex-1 w-full">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-white font-bold text-base md:text-lg">{match.home}</span>
                            <div className="text-right">
                              <span className="text-blue-300 text-base md:text-lg font-bold">{match.time}</span>
                              <p className="text-blue-400 text-xs md:text-sm">
                                {match.tournament} - {match.surface}
                              </p>
                            </div>
                          </div>
                          <div className="text-white font-bold text-base md:text-lg">{match.away}</div>
                        </div>
                        <div className="flex space-x-2 md:space-x-3 w-full md:w-auto md:ml-6">
                          <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                          >
                            1<br />
                            {match.odds["1"]}
                          </Button>
                          <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 min-w-[60px] md:min-w-[80px] h-12 md:h-16 text-sm md:text-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105 flex-1 md:flex-none"
                          >
                            2<br />
                            {match.odds["2"]}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </div>

          {/* Bet Slip */}
          <div className="lg:col-span-1">
            <BetSlip selectedBets={selectedBets} onRemoveBet={removeBet} onClearAll={clearAllBets} />
          </div>
        </div>
      </div>
    </div>
  )
}
