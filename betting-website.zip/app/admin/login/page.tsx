"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Trophy, Shield, Lock, User } from "lucide-react"
import { useRouter } from "next/navigation"
import { adminAuthService } from "@/lib/admin-auth"

export default function AdminLoginPage() {
  const router = useRouter()
  const [loginData, setLoginData] = useState({ username: "", password: "" })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      const admin = adminAuthService.login(loginData.username, loginData.password)

      if (admin) {
        router.push("/admin")
      } else {
        setError("Invalid username or password")
      }
    } catch (err) {
      setError("Login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 flex items-center justify-center">
      <div className="container mx-auto px-4">
        <div className="max-w-md mx-auto">
          <Card className="bg-white/10 border-blue-600 shadow-2xl backdrop-blur-sm">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="relative">
                  <Trophy className="h-16 w-16 text-yellow-400" />
                  <Shield className="h-8 w-8 text-blue-400 absolute -bottom-2 -right-2" />
                </div>
              </div>
              <CardTitle className="text-3xl text-white font-bold">Admin Login</CardTitle>
              <CardDescription className="text-blue-300 text-lg">SportBet Pro Administration Panel</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-6">
                <div>
                  <Label htmlFor="username" className="text-white text-lg font-bold">
                    Username
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-blue-400" />
                    <Input
                      id="username"
                      type="text"
                      placeholder="Enter username"
                      value={loginData.username}
                      onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                      className="bg-white/10 border-blue-600 text-white pl-12 h-14 text-lg"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="password" className="text-white text-lg font-bold">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-blue-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter password"
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      className="bg-white/10 border-blue-600 text-white pl-12 h-14 text-lg"
                      required
                    />
                  </div>
                </div>

                {error && (
                  <div className="bg-red-600/20 border border-red-500 rounded-lg p-4">
                    <p className="text-red-400 text-center font-bold">{error}</p>
                  </div>
                )}

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-4 text-lg shadow-xl transition-all duration-300 transform hover:scale-105"
                  disabled={isLoading}
                >
                  {isLoading ? "Logging in..." : "Login to Admin Panel"}
                </Button>
              </form>

              <div className="mt-8 p-6 bg-blue-600/20 rounded-lg border border-blue-500">
                <h4 className="text-white font-bold mb-3 text-lg">Demo Credentials:</h4>
                <div className="space-y-2 text-blue-300">
                  <p>
                    <strong>Super Admin:</strong> admin / admin123
                  </p>
                  <p>
                    <strong>Manager:</strong> manager / manager123
                  </p>
                  <p>
                    <strong>Support:</strong> support / support123
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
