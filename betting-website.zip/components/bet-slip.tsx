"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, X, Clock } from "lucide-react"
import { authService } from "@/lib/auth"
import { MinBetPopup } from "@/components/min-bet-popup"

interface BetSlipProps {
  selectedBets: any[]
  onRemoveBet: (index: number) => void
  onClearAll: () => void
}

export function BetSlip({ selectedBets, onRemoveBet, onClearAll }: BetSlipProps) {
  const [stake, setStake] = useState("")
  const [userBets, setUserBets] = useState<any[]>([])
  const [showMinBetPopup, setShowMinBetPopup] = useState(false)

  // Get current user once and memoize it
  const currentUser = useMemo(() => authService.getCurrentUser(), [])
  const currentUserId = currentUser?.id

  // Calculate potential win with useMemo to prevent recalculation on every render
  const potentialWin = useMemo(() => {
    const stakeAmount = Number.parseFloat(stake) || 0
    const totalOdds = selectedBets.reduce((acc, bet) => acc * bet.odds, 1)
    return stakeAmount * totalOdds
  }, [stake, selectedBets])

  // Memoize the total odds calculation
  const totalOdds = useMemo(() => {
    return selectedBets.reduce((acc, bet) => acc * bet.odds, 1)
  }, [selectedBets])

  // Use useCallback to stabilize the function reference
  const loadUserBets = useCallback(() => {
    if (currentUserId) {
      const bets = authService.getUserBets(currentUserId)
      setUserBets(bets)
    }
  }, [currentUserId])

  // Load user bets only when user ID changes
  useEffect(() => {
    loadUserBets()
  }, [loadUserBets])

  const handlePlaceBet = useCallback(() => {
    if (!currentUser || selectedBets.length === 0 || !stake) return

    const stakeAmount = Number.parseFloat(stake)
    if (stakeAmount < 10) {
      setShowMinBetPopup(true)
      return
    }

    if (stakeAmount > currentUser.balance) {
      alert("Insufficient balance")
      return
    }

    // Place bet
    const betData = {
      userId: currentUser.id,
      match: selectedBets.map((bet) => bet.match).join(", "),
      selection: selectedBets.map((bet) => `${bet.bet} @ ${bet.odds}`).join(", "),
      odds: totalOdds,
      stake: stakeAmount,
      potentialWin: potentialWin,
      status: "Pending" as const,
    }

    authService.placeBet(betData)
    authService.updateUserBalance(currentUser.id, currentUser.balance - stakeAmount)

    // Clear bet slip
    onClearAll()
    setStake("")

    // Reload user bets
    loadUserBets()

    alert("Bet placed successfully!")
  }, [currentUser, selectedBets, stake, totalOdds, potentialWin, onClearAll, loadUserBets])

  return (
    <>
      {/* Min Bet Popup */}
      {showMinBetPopup && <MinBetPopup onClose={() => setShowMinBetPopup(false)} />}

      <Card className="bg-white/10 border-blue-600 sticky top-24">
        <Tabs defaultValue="betslip" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-blue-700">
            <TabsTrigger value="betslip" className="data-[state=active]:bg-blue-600">
              Bet Slip
            </TabsTrigger>
            <TabsTrigger value="mybets" className="data-[state=active]:bg-blue-600">
              My Bets
            </TabsTrigger>
          </TabsList>

          <TabsContent value="betslip">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <div className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Bet Slip
                </div>
                {selectedBets.length > 0 && (
                  <Button size="sm" variant="ghost" onClick={onClearAll} className="text-red-400 hover:text-red-300">
                    Clear All
                  </Button>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedBets.length === 0 ? (
                <p className="text-white/60 text-center py-8">Click on odds to add selections</p>
              ) : (
                <>
                  {selectedBets.map((bet, index) => (
                    <div
                      key={`${bet.match}-${bet.bet}-${index}`}
                      className="bg-white/5 p-3 rounded border border-blue-600"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-white text-sm font-medium">{bet.match}</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-red-400 hover:text-red-300 h-6 w-6 p-0"
                          onClick={() => onRemoveBet(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-blue-300 text-sm">{bet.bet}</span>
                        <span className="text-yellow-400 font-bold">{bet.odds}</span>
                      </div>
                    </div>
                  ))}

                  <div className="space-y-3 pt-4 border-t border-blue-600">
                    <div>
                      <Label htmlFor="stake" className="text-white">
                        Stake (KSH)
                      </Label>
                      <Input
                        id="stake"
                        type="number"
                        placeholder="100"
                        value={stake}
                        onChange={(e) => setStake(e.target.value)}
                        className="bg-white/10 border-blue-600 text-white"
                        min="10"
                      />
                    </div>

                    <div className="flex justify-between text-white">
                      <span>Total Odds:</span>
                      <span className="font-bold text-yellow-400">{totalOdds.toFixed(2)}</span>
                    </div>

                    <div className="flex justify-between text-white">
                      <span>Potential Win:</span>
                      <span className="font-bold text-green-400">KSH {potentialWin.toFixed(2)}</span>
                    </div>

                    <Button
                      className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold"
                      onClick={handlePlaceBet}
                      disabled={!currentUser || selectedBets.length === 0 || !stake}
                    >
                      Place Bet
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </TabsContent>

          <TabsContent value="mybets">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                My Bets
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {userBets.length === 0 ? (
                <p className="text-white/60 text-center py-8">No bets placed yet</p>
              ) : (
                userBets.map((bet) => (
                  <div key={bet.id} className="bg-white/5 p-3 rounded border border-blue-600">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-white text-sm font-medium">{bet.match}</span>
                      <Badge
                        variant={bet.status === "Won" ? "default" : bet.status === "Lost" ? "destructive" : "secondary"}
                        className={
                          bet.status === "Won" ? "bg-green-600" : bet.status === "Lost" ? "bg-red-600" : "bg-yellow-600"
                        }
                      >
                        {bet.status}
                      </Badge>
                    </div>
                    <div className="text-blue-300 text-sm mb-2">{bet.selection}</div>
                    <div className="flex justify-between text-sm">
                      <span className="text-white">Stake: KSH {bet.stake}</span>
                      <span className="text-green-400">Win: KSH {bet.potentialWin.toFixed(2)}</span>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </TabsContent>
        </Tabs>
      </Card>
    </>
  )
}
