"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, X, Clock, DollarSign, AlertTriangle } from "lucide-react"

interface NotificationProps {
  type: "success" | "info" | "warning" | "error"
  title: string
  message: string
  details?: string[]
  onClose: () => void
  autoClose?: boolean
  duration?: number
}

export function Notification({
  type,
  title,
  message,
  details,
  onClose,
  autoClose = true,
  duration = 4000, // Reduced from 5000
}: NotificationProps) {
  const [isVisible, setIsVisible] = useState(true)
  const [progress, setProgress] = useState(100)

  useEffect(() => {
    if (autoClose) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev - 100 / (duration / 100)
          if (newProgress <= 0) {
            setIsVisible(false)
            setTimeout(onClose, 300)
            return 0
          }
          return newProgress
        })
      }, 100)

      return () => clearInterval(interval)
    }
  }, [autoClose, duration, onClose])

  const getIcon = () => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-6 w-6 text-green-400" />
      case "info":
        return <DollarSign className="h-6 w-6 text-blue-400" />
      case "warning":
        return <Clock className="h-6 w-6 text-yellow-400" />
      case "error":
        return <AlertTriangle className="h-6 w-6 text-red-400" />
    }
  }

  const getColors = () => {
    switch (type) {
      case "success":
        return "from-green-500/30 to-green-600/30 border-green-500"
      case "info":
        return "from-blue-500/30 to-blue-600/30 border-blue-500"
      case "warning":
        return "from-yellow-500/30 to-yellow-600/30 border-yellow-500"
      case "error":
        return "from-red-500/30 to-red-600/30 border-red-500"
    }
  }

  const getProgressColor = () => {
    switch (type) {
      case "success":
        return "bg-green-500"
      case "info":
        return "bg-blue-500"
      case "warning":
        return "bg-yellow-500"
      case "error":
        return "bg-red-500"
    }
  }

  if (!isVisible) return null

  return (
    <div className="fixed top-4 right-4 left-4 md:left-auto z-50 animate-in slide-in-from-top duration-300">
      <Card className={`bg-gradient-to-r ${getColors()} shadow-2xl backdrop-blur-sm max-w-sm mx-auto md:mx-0`}>
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0">{getIcon()}</div>
            <div className="flex-1 min-w-0">
              <h3 className="text-white font-bold text-base mb-1">{title}</h3>
              <p className="text-white/90 text-sm">{message}</p>

              {/* Show only the first detail for mobile */}
              {details && details.length > 0 && <p className="text-white/80 text-xs mt-2 truncate">{details[0]}</p>}
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setIsVisible(false)
                setTimeout(onClose, 300)
              }}
              className="text-white hover:bg-white/20 h-6 w-6 p-0 flex-shrink-0"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
          {autoClose && (
            <div className="mt-3">
              <div className="w-full bg-white/20 rounded-full h-1">
                <div
                  className={`h-1 rounded-full transition-all duration-100 ${getProgressColor()}`}
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
